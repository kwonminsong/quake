package com.quakesurvival.actors;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas.AtlasRegion;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.JointEdge;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.quakesurvival.game.attribute.Player;
import com.quakesurvival.screen.AbstractScreen;
import com.quakesurvival.screen.SchoolScreen;

public class HeavyObjectActor extends Actor 
{
	private Body heavyObjectBody;
	private AtlasRegion atlas;

	
	public HeavyObjectActor(World world, float posX, float posY, float angle, float sizeX, float sizeY)
	{
		/* �ٵ� ���� */
		heavyObjectBody = world.createBody(new BodyDef());
		heavyObjectBody.setTransform((Gdx.graphics.getWidth() * posX) * SchoolScreen.WorldToBox, (Gdx.graphics.getHeight() * posY) * SchoolScreen.WorldToBox, angle);
	
		/* ���� ���� */
		FixtureDef heavyObjectFixtureDef = new FixtureDef();
		
		/* ��� ���� */
		PolygonShape heavyObjectShape = new PolygonShape();
		
		/* ũ�� ���� �� �ݿ� */
		heavyObjectShape.setAsBox((AbstractScreen.WIDTH * sizeX) * SchoolScreen.WorldToBox, (AbstractScreen.HEIGHT * sizeY) * SchoolScreen.WorldToBox);
		heavyObjectFixtureDef.shape = heavyObjectShape;
		
		/* ���� ���� */
		heavyObjectFixtureDef.density = 10000.0F;		// ���� (kg/m^2)
		heavyObjectFixtureDef.friction = 1.0F;		// ������ (0 ~ 1)
		heavyObjectFixtureDef.restitution = 0.0F;	// ź���� (0 ~ 1)
		
		/* ���� �ݿ� */
		heavyObjectBody.createFixture(heavyObjectFixtureDef);

	}
	
	@Override
	public void act(float delta)
	{
		super.act(delta);
	}
	
	@Override
	public void draw (Batch batch, float parentAlpha)
	{
		super.draw(batch, parentAlpha);
	}


	
	public void setDynamicBody()
	{
		heavyObjectBody.setType(BodyType.DynamicBody);
	}
	
	public void pullDown(float impulse)
	{
		heavyObjectBody.applyAngularImpulse(impulse, true);
	}
	
	public Rectangle getBounds() 
	{		
		return new Rectangle(getX(), getY(), getWidth(), getHeight());
	}
}

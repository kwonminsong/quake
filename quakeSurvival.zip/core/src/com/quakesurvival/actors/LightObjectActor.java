package com.quakesurvival.actors;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas.AtlasRegion;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.quakesurvival.screen.SchoolScreen;

public class LightObjectActor extends Actor
{
	private Body lightObjectBody;
	private AtlasRegion atlas;
	private boolean collapsing;
	
	public LightObjectActor(World world, float posX, float posY, float angle, float sizeX, float sizeY)
	{
		/* �ٵ� ���� */
		lightObjectBody = world.createBody(new BodyDef());
		lightObjectBody.setTransform((Gdx.graphics.getWidth() * posX) * SchoolScreen.WorldToBox, (Gdx.graphics.getHeight() * posY) * SchoolScreen.WorldToBox, angle);
	
		/* ���� ���� */
		FixtureDef lightObjectFixtureDef = new FixtureDef();
		
		/* ��� ���� */
		PolygonShape lightObjectShape = new PolygonShape();
		
		/* ũ�� ���� �� �ݿ� */
		lightObjectShape.setAsBox((Gdx.graphics.getWidth() * sizeX) * SchoolScreen.WorldToBox, (Gdx.graphics.getHeight() * sizeY) * SchoolScreen.WorldToBox);
		lightObjectFixtureDef.shape = lightObjectShape;
		
		/* ���� ���� */
		lightObjectFixtureDef.density = 500.0F;		// ���� (kg/m^2)
		lightObjectFixtureDef.friction = 1.0F;		// ������ (0 ~ 1)
		lightObjectFixtureDef.restitution = 0.5F;	// ź���� (0 ~ 1)
		
		/* ���� �ݿ� */
		lightObjectBody.createFixture(lightObjectFixtureDef);	
	}
	
	@Override
	public void act(float delta)
	{	
		super.act(delta);
		
		this.setPosition(lightObjectBody.getPosition().x, lightObjectBody.getPosition().y);
		this.setRotation(lightObjectBody.getAngle());
	}
	
	@Override
	public void draw (Batch batch, float parentAlpha)
	{
		super.draw(batch, parentAlpha);
	}
	
	
	private void checkCollapsing()
	{
		
	}
	public void setDynamicBody()
	{
		if(!collapsing)
		{
			lightObjectBody.setType(BodyType.DynamicBody);
			collapsing = true;
		}
	}
	
	public void throwDown(float impulse)
	{
		lightObjectBody.applyAngularImpulse(impulse, true);
	}
	
	public Rectangle getBounds() 
	{		
		return new Rectangle(getX(), getY(), getWidth(), getHeight());
	}

}

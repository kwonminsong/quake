

package com.quakesurvival.actors;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureAtlas.AtlasRegion;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.EdgeShape;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.JointEdge;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.quakesurvival.game.attribute.Player;
import com.quakesurvival.screen.SchoolScreen;

public class PlayerActor extends Actor 
{
	private World world;	// ����
	private Player player;
	private Body playerBody;
	private boolean leftMoving, rightMoving, floating;
	private float velocity;
	
	public PlayerActor(World world)
	{
		this.world = world;
		this.velocity = 2.0F;
		this.player = new Player();
		
		BodyDef playerBodyDef = new BodyDef();
		playerBodyDef.type = BodyType.DynamicBody;
		playerBody = this.world.createBody(playerBodyDef);
		playerBody.setTransform((Gdx.graphics.getWidth() * 0.5F) * SchoolScreen.WorldToBox, (Gdx.graphics.getHeight() * 0.175F) * SchoolScreen.WorldToBox, 0);
		
		FixtureDef playerFixtureDef = new FixtureDef();	// ���� ����
		
		CircleShape playerCircleShape = new CircleShape();
		//playerPolygonShape.setAsBox((Gdx.graphics.getHeight() * 0.05F) * SchoolScreen.WorldToBox, (Gdx.graphics.getHeight() * 0.08F) * SchoolScreen.WorldToBox);
		
		playerCircleShape.setRadius(0.4F);
		playerFixtureDef.shape = playerCircleShape;
		playerFixtureDef.density = 50.0F;		// ���� (kg/m^2)
		playerFixtureDef.friction = 0.7F;		// ������ (0 ~ 1)
		playerFixtureDef.restitution = 0.0F;	// ź���� (0 ~ 1)
	
		playerBody.createFixture(playerFixtureDef);
		
		EdgeShape playerHeadShape = new EdgeShape();
		playerHeadShape.set(-0.2F, 0.4F, 0.2F, 0.4F);

		playerFixtureDef.shape = playerHeadShape;
		
		playerBody.createFixture(playerFixtureDef);
		
		playerBody.setFixedRotation(true);
		playerBody.setUserData(this);
	}
	
	@Override
	public void act(float delta)
	{	
		super.act(delta);
		this.checkFloating();
		this.move();
		this.setPosition(playerBody.getPosition().x, playerBody.getPosition().y);
		this.setRotation(playerBody.getAngle());
	}
	
	@Override
	public void draw (Batch batch, float parentAlpha)
	{
		super.draw(batch, parentAlpha);
		
	}
	
	public void dead()
	{
		playerBody.setType(BodyType.StaticBody);
	}
	
	
	private void move()
	{
		if(leftMoving && playerBody.getLinearVelocity().x > -velocity)
		{
			playerBody.applyForceToCenter(-1100F, 0, true);
		}
		else if(rightMoving && playerBody.getLinearVelocity().x < velocity)
		{
			playerBody.applyForceToCenter(1100F, 0, true);
		}
		else
		{
			
		}
			
	}
	
	private void checkFloating()
	{
		if(playerBody.getLinearVelocity().y > 0 || playerBody.getLinearVelocity().y < 0)
		{
			floating = true;
		}
		else
		{
			floating = false;
		}
	}
	
	public void setMoveLeft(boolean state)
	{
		if(rightMoving && state)
		{
			rightMoving = false;
		}
		
		leftMoving = state;
		
	}
	
	public void setMoveRight(boolean state)
	{
		if(leftMoving && state)
		{
			leftMoving = false;
		}
		
		rightMoving = state;
	}
	
	public void sit()
	{
		
	}
	
	public Rectangle getBounds() 
	{		
		return new Rectangle(getX(), getY(), getWidth(), getHeight());
	}
	
}

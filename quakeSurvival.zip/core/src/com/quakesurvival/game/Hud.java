package com.quakesurvival.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator.FreeTypeFontParameter;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.Disposable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.quakesurvival.screen.AbstractScreen;

public class Hud implements Disposable
{
    public Stage stage;
    private Viewport viewport;
    private BitmapFont font;

    private Label countdownLabel, quakeLabel;
    private Label timeLabel;
    
    private int countdown, quakeTimer;
    private boolean timeUp; // true when the world timer reaches 0
    private float timeCount;
    
    public Hud(SpriteBatch spriteBatch)
    {
        //define our tracking variables
        quakeTimer = 30;
        timeCount = 0;
       
        
        viewport = new FitViewport(Gdx.graphics.getWidth(), Gdx.graphics.getHeight(), new OrthographicCamera());
        stage = new Stage(viewport, spriteBatch);

        //define a table used to organize our hud's labels
        Table table = new Table();
        //Top-Align table
        table.top();
        //make the table fill the entire stage
        table.setFillParent(true);


        countdownLabel = new Label(String.format("%03d", quakeTimer), new Label.LabelStyle(new BitmapFont(), Color.BLACK));
       
        timeLabel = new Label("TIME", new Label.LabelStyle(new BitmapFont(), Color.BLACK));
        quakeLabel = new Label("", new Label.LabelStyle(new BitmapFont(), Color.BLACK));

        FreeTypeFontGenerator generator = new FreeTypeFontGenerator(Gdx.files.internal("RixVideoGame.ttf"));
        FreeTypeFontParameter parameter = new FreeTypeFontParameter();
        
        parameter.characters = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ~!@#$%^*()_+{}[],./;'\"<>?:�ð�����";
        parameter.size = 30;
        font = generator.generateFont(parameter);
        
        
        timeLabel = new Label("�ð�", new Label.LabelStyle(font, Color.BLACK));
        quakeLabel = new Label("        ", new Label.LabelStyle(font, Color.RED));
        countdownLabel = new Label("   ", new Label.LabelStyle(font, Color.BLACK));
        
        table.add(timeLabel).expandX().padTop(10);
        table.add(quakeLabel).expandX().padTop(10);
        
        table.row();
        table.add(countdownLabel).expandX();
        
        stage.addActor(table);
    }

    public void update(boolean quakeStart, int countdown)
    {
    	if(quakeStart)
    	{
    		if(countdown % 2 == 0)
    		{
    			quakeLabel.setText("����!");
    		}
    		else
    		{
    			quakeLabel.setText("        ");
    		}
    		countdownLabel.setText(String.format("%03d", countdown));
    	}
    	
    	
    	
    }



    @Override
    public void dispose() 
    {
    	stage.dispose(); 
    }

    public boolean isTimeUp() { return timeUp; }
}

package com.quakesurvival.game;


import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.quakesurvival.screen.MainMenuScreen;
import com.quakesurvival.screen.SchoolScreen;
import com.quakesurvival.screen.ScoreScreen;
import com.quakesurvival.screen.SettingScreen;
import com.quakesurvival.screen.SplashScreen;

public class QuakeSurvivalGame extends Game 
{
	public SpriteBatch batch;
	private MainMenuScreen mainMenuScreen;
	private SchoolScreen schoolScreen;
	private SettingScreen settingScreen;
	private ScoreScreen scoreScreen;
	private SplashScreen splashScreen;


	@Override
	public void create()
	{
		batch = new SpriteBatch();
		
		mainMenuScreen = new MainMenuScreen(this);
		settingScreen = new SettingScreen(this);
		scoreScreen = new ScoreScreen(this);
		
		this.setMainMenuScreen();
		
	}
	
	public void createSchoolScreen()
	{
		this.setScreen(new SchoolScreen(this));
	}
	
	public void setMainMenuScreen()
	{
		this.setScreen(mainMenuScreen);
	}
	
	public void setSettingScreen()
	{
		this.setScreen(settingScreen);
	}
	
	public void setScoreScreen()
	{
		this.setScreen(scoreScreen);
	}
	
	

/*
	@Override
	public void render () {
		Gdx.gl.glClearColor(1, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		batch.begin();
		batch.draw(img, 0, 0);
		batch.end();
	}
*/
	
	@Override
	public void dispose() 
	{
		super.dispose();
		batch.dispose();
	}

}

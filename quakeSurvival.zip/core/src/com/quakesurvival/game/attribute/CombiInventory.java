package com.quakesurvival.game.attribute;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.Array;
import com.quakesurvival.game.attribute.Item;
import com.quakesurvival.game.controls.Slot;

/**
 * @brief ����â�� ������ �����ϰ�, ����â���� � �۾��� �ϴ��� �����Ѵ�.
 * @n
 * @author �ǹμ� 
 * @date 2016-12-27
 * @version 1.0.0
 */
public class CombiInventory 
{

	private static Array<Slot> slots;
	/**
	 * @details ����â���� �ʿ��� �κ��丮�� ����
	 * @n
	 */
	public CombiInventory() 
	{
		slots = new Array<Slot>(3);
		for (int i = 0; i < 3; i++) 
		{
			slots.add(new Slot(null, 0));
		}
	}

	public int checkInventory(Item item) 
	{
		int amount = 0;

		for (Slot slot : slots) 
		{
			if (slot.getItem() == item) 
			{
				amount += slot.getAmount();
			}
		}

		return amount;
	}

	/**
	 * @details ����â�� �������� �߰�
	 * @n
	 * @param Item item
	 * @param int amount
	 * @return boolean
	 */
	public boolean store(Item item, int amount) 
	{
		Slot itemSlot = firstItem(item);
		if (itemSlot != null) 
		{
			itemSlot.add(item, amount);
			return true;
		} 
		else 
		{
			Slot emptySlot = firstItem(null);
			if (emptySlot != null)
			{
				emptySlot.add(item, amount);
				return true;
			}
		}
		
		return false;
	}

	public static Array<Slot> getSlots() 
	{
		return slots;
	}
	/**
	 * @details slot�� ������ �������� �ִٸ� ������ ����
	 * @n
	 * @param Array<Slot> slots
	 */
	public static void make(Array<Slot> slots) {
	if(((slots.get(0).getItem() != null && slots.get(1).getItem() != null) 
			&& (slots.get(0).getItem().getTextureRegion().equals("plasticbottle") 
			&& slots.get(1).getItem().getTextureRegion().equals("scissors")))
			|| ((slots.get(0).getItem() != null && slots.get(1).getItem() != null)
			&&(slots.get(1).getItem().getTextureRegion().equals("plasticbottle") 
			&& slots.get(0).getItem().getTextureRegion().equals("scissors")))) {
		slots.get(2).add(Item.values()[6], 1);
		
		for(int i = 0; i <2; i++){
			slots.get(i).take(slots.get(i).getAmount());
		}
	}
	
	if(((slots.get(0).getItem() != null && slots.get(1).getItem() != null) 
			&& (slots.get(0).getItem().getTextureRegion().equals("rnewspaper") 
			&& slots.get(1).getItem().getTextureRegion().equals("plasticbag")))
			|| ((slots.get(0).getItem() != null && slots.get(1).getItem() != null)
			&&(slots.get(1).getItem().getTextureRegion().equals("newspaper") 
			&& slots.get(0).getItem().getTextureRegion().equals("plasticbag")))) {
		slots.get(2).add(Item.values()[7], 1);
		
		for(int i = 0; i <2; i++){
			slots.get(i).take(slots.get(i).getAmount());
		}
	}

	if(((slots.get(0).getItem() != null && slots.get(1).getItem() != null) 
			&& (slots.get(0).getItem().getTextureRegion().equals("battery") 
			&& slots.get(1).getItem().getTextureRegion().equals("notbatteryflashlight")))
			|| ((slots.get(0).getItem() != null && slots.get(1).getItem() != null)
			&&(slots.get(1).getItem().getTextureRegion().equals("battery") 
			&& slots.get(0).getItem().getTextureRegion().equals("notbatteryflashlight")))) {
		slots.get(2).add(Item.values()[8], 1);
		
		for(int i = 0; i <2; i++){
			slots.get(i).take(slots.get(i).getAmount());
		}
	}
	if(((slots.get(0).getItem() != null && slots.get(1).getItem() != null) 
			&& (slots.get(0).getItem().getTextureRegion().equals("flashlight") 
			&& slots.get(1).getItem().getTextureRegion().equals("plasticbag")))
			|| ((slots.get(0).getItem() != null && slots.get(1).getItem() != null)
			&&(slots.get(1).getItem().getTextureRegion().equals("flashlight") 
			&& slots.get(0).getItem().getTextureRegion().equals("plasticbag")))) {
		slots.get(2).add(Item.values()[9], 1);
		
		for(int i = 0; i <2; i++){
			slots.get(i).take(slots.get(i).getAmount());
		}
	}
}

	private Slot firstItem(Item item)
	{
		for (Slot slot : slots) 
		{
			if (slot.getItem() == item) 
			{
				return slot;
			}
		}

		return null;
	}
}

package com.quakesurvival.game.attribute;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.Array;
import com.quakesurvival.game.controls.Slot;

public class FAidInventory {

	private static Array<Slot> slots;
	
	public FAidInventory() {
		slots = new Array<Slot>(5);

		for (int i = 0; i < 5; i++) {
			slots.add(new Slot(null, 0));
		}
		List<Integer> list = new ArrayList<Integer>();
		for(int i=0; i< 5; i++) {
		list.add(i + 10);
		}
		Collections.shuffle(list);

		for(int i=0; i< 5; i++) {
		slots.get(i).add(Item.values()[list.get(i)], 1);
		}
	}

	public int checkInventory(Item item) {
		int amount = 0;

		for (Slot slot : slots) {
			if (slot.getItem() == item) {
				amount += slot.getAmount();
			}
		}

		return amount;
	}

	public boolean store(Item item, int amount) {
	
		Slot itemSlot = firstItem(item);
		if (itemSlot != null) {
			itemSlot.add(item, amount);
			return true;
		} else {
		
			Slot emptySlot = firstItem(null);
			if (emptySlot != null) {
				emptySlot.add(item, amount);
				return true;
			}
		}


		return false;
	}

	public static Array<Slot> getSlots() {
		return slots;
	}

	private Slot firstItem(Item item) {
		for (Slot slot : slots) {
			if (slot.getItem() == item) {
				return slot;
			}
		}

		return null;
	}
	
	public static boolean cure(Array<Slot> slots){
		if(slots.get(0).getItem().getTextureRegion().equals("confirmceremony")
				&& slots.get(1).getItem().getTextureRegion().equals("HelpRequest")
				&& slots.get(2).getItem().getTextureRegion().equals("checkbreath")
				&& slots.get(3).getItem().getTextureRegion().equals("compression")
				&& slots.get(4).getItem().getTextureRegion().equals("CPR")){
				return true;
		}
		return false;
	}

}

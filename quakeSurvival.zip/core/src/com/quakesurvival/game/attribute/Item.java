package com.quakesurvival.game.attribute;
/**
 * @brief ������ ���
 * @n
 * @author �ǹμ� 
 * @date 2016-12-27
 * @version 1.0.0
 */

public enum Item {

	NEWSPAPER("newspaper"), PLASTIC_BAG("plasticbag"), 
	PLASTIC_BOTTLE("plasticbottle"), SCISSORS("scissors"),
	BATTERY("battery"), NOTBATTERYFLASHLIGHT("notbatteryflashlight"), 
	BOWL("bowl"), LAGS("lags"), FLASHLIGHT("flashlight"), LAPPIN_GLIGHT("lappinglight"),
	CHECK_BREATH("checkbreath"), COMPRESSION("compression"), CONFIRM_CEREMONY("confirmceremony"),
	CPR("CPR"), HELP_REQUEST("HelpRequest");

	private String textureRegion;

	private Item(String textureRegion) {
		this.textureRegion = textureRegion;
	}

	public String getTextureRegion() {
		return textureRegion;
	}

}


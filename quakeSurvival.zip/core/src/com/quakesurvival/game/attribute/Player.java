package com.quakesurvival.game.attribute;

public class Player 
{
	public static final int MAX_HUNGRY = 100;
	public static final int MIN_HUNGRY = 0;
	public static final int MAX_THIRST = 100;
	public static final int MIN_THIRST = 0;
	
	private int hungry, thirst;
	private float temperture;
	
	public Player()
	{
		this.temperture = 36.5F;
		this.hungry = 50;
		this.thirst = 50;
	}
	
	public void updateState()
	{
		
	}
	
	public int getHungry()
	{
		return hungry;
	}
	
	public int getThirst()
	{
		return thirst;
	}
	
	public float getTemperture()
	{
		return temperture;
	}
	
}
	
package com.quakesurvival.game.attribute;

public class Supplies 
{
	private int bread, water;
	
	public Supplies(int bread, int water)
	{
		this.bread = bread;
		this.water = water;
	}
	
	public boolean consume(int bread, int water)
	{
		if(this.bread < bread || this.water < water)
		{
			return false;
		}
		
		this.bread -= bread;
		this.water -= water;
	
		return true;
	}
}

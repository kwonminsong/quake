package com.quakesurvival.game.controls;

import java.util.LinkedList;
import java.util.Random;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.quakesurvival.actors.HeavyObjectActor;
import com.quakesurvival.actors.LightObjectActor;
import com.quakesurvival.screen.AbstractScreen;

public class Building 
{
	/*
	private LinkedList<HeavyObjectActor> heavyObjectActors;
	private LinkedList<LightObjectActor> lightObjectActors;
	*/
	
	private HeavyObjectActor bottomActor, floorActor;
	private HeavyObjectActor[] ceilingActor, wallActor;
	private LightObjectActor[] pieceActor, lampActor, shelfActor, cupboardActor, mirrorActor, bookShelfActor, book, ball;
	private boolean collapsing = false;
	
	public Building(Stage stage, World world, int floor)
	{
		bottomActor = new HeavyObjectActor(world, 0.5F, 0.025F, 0.0F, 1.5F, 0.025F);
		stage.addActor(bottomActor);
		
		floorActor = new HeavyObjectActor(world, 0.5F, 0.075F, 0.0F, 0.8F, 0.025F);
		stage.addActor(floorActor);
		
		ceilingActor = new HeavyObjectActor[4];
		ceilingActor[0] = new HeavyObjectActor(world, 0.3F, 0.475F, 0.0F, 0.6F, 0.025F);
		ceilingActor[1] = new HeavyObjectActor(world, 1.1F, 0.475F, 0.0F, 0.2F, 0.025F);
		ceilingActor[2] = new HeavyObjectActor(world, 0.1F, 0.875F, 0.0F, 0.4F, 0.025F);
		ceilingActor[3] = new HeavyObjectActor(world, 0.9F, 0.875F, 0.0F, 0.4F, 0.025F);
		
		for(int i = 0; i < ceilingActor.length; i++)
		{
			stage.addActor(ceilingActor[i]);
		}
		

		wallActor = new HeavyObjectActor[4];
		wallActor[0] = new HeavyObjectActor(world, -0.275F, 0.275F, 0.0F, 0.025F, 0.175F);
		wallActor[1] = new HeavyObjectActor(world, 1.275F, 0.275F, 0.0F, 0.025F, 0.175F);
		wallActor[2] = new HeavyObjectActor(world, -0.275F, 0.675F, 0.0F, 0.025F, 0.175F);
		wallActor[3] = new HeavyObjectActor(world, 1.275F, 0.675F, 0.0F, 0.025F, 0.175F);
		
		for(int i = 0; i < wallActor.length; i++)
		{
			stage.addActor(wallActor[i]);
		}
		
		
		pieceActor = new LightObjectActor[30];
		
		float posX = -0.2F;
		for(int i = 0; i < pieceActor.length/2; i++)
		{
			pieceActor[i] = new LightObjectActor(world, posX, 0.845F, 0.0F, 0.05F, 0.005F);
			stage.addActor(pieceActor[i]);
			posX += 0.1F;
		}
		
		posX = -0.2F;
		for(int i = pieceActor.length/2; i < pieceActor.length; i++)
		{
			pieceActor[i] = new LightObjectActor(world, posX, 0.445F, 0.0F, 0.05F, 0.005F);
			stage.addActor(pieceActor[i]);
			posX += 0.1F;
		}
		
		
		lampActor = new LightObjectActor[6];
		lampActor[0] = new LightObjectActor(world, 0.0F, 0.83F, 0.0F, 0.05F, 0.01F);
		lampActor[1] = new LightObjectActor(world, 0.5F, 0.83F, 0.0F, 0.05F, 0.01F);
		lampActor[2] = new LightObjectActor(world, 1.0F, 0.83F, 0.0F, 0.05F, 0.01F);
		lampActor[3] = new LightObjectActor(world, 0.0F, 0.43F, 0.0F, 0.05F, 0.01F);
		lampActor[4] = new LightObjectActor(world, 0.5F, 0.43F, 0.0F, 0.05F, 0.01F);
		lampActor[5] = new LightObjectActor(world, 1.0F, 0.43F, 0.0F, 0.05F, 0.01F);
		
		for(int i = 0; i < lampActor.length; i++)
		{
			stage.addActor(lampActor[i]);
		}
		
		/*
		shelfActor = new LightObjectActor[3];
		shelfActor[0] = new LightObjectActor(world, 0.25F, 0.325F, 0.0F, 0.06F, 0.01F);
		shelfActor[1] = new LightObjectActor(world, 0.45F, 0.325F, 0.0F, 0.06F, 0.01F);
		*/
		
		/*
		heavyObjectActors = new LinkedList<HeavyObjectActor>();
		for(int i = 0; i < ceilingActor.length; i++)
		{
			heavyObjectActors.add(ceilingActor[i]);
		}	
		for(int i = 0; i < wallActor.length; i++)
		{
			heavyObjectActors.add(wallActor[i]);
		}
		
		lightObjectActors = new LinkedList<LightObjectActor>();
		for(int i = 0; i < pieceActor.length; i++)
		{
			lightObjectActors.add(pieceActor[i]);
		}
		for(int i = 0; i < lampActor.length; i++)
		{
			lightObjectActors.add(lampActor[i]);
		}
		*/
		
	}

	public boolean isCollapsing()
	{
		return collapsing;
	}
	
	public void throwDown()
	{
		Random random = new Random();

		pieceActor[random.nextInt(pieceActor.length - 1)].setDynamicBody();
		lampActor[random.nextInt(lampActor.length - 1)].setDynamicBody();
	}
	
	public void collapse()
	{
		if(!collapsing)
		{	
			for(int i = 0; i < ceilingActor.length; i++)
			{
				ceilingActor[i].setDynamicBody();
			}
			
			for(int i = 1; i < wallActor.length; i++)
			{
				wallActor[i].setDynamicBody();
			}
			
			for(int i = 0; i < pieceActor.length; i++)
			{
				pieceActor[i].setDynamicBody();
			}
			
			for(int i = 0; i < lampActor.length; i++)
			{
				lampActor[i].setDynamicBody();
			}
			
			for(int i = 0; i < ceilingActor.length; i++)
			{
				ceilingActor[i].pullDown(i%2==1?-10000:10000);
			}
			collapsing = true;
		}
	}



}
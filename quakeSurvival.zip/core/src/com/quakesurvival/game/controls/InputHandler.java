package com.quakesurvival.game.controls;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.quakesurvival.actors.PlayerActor;

public class InputHandler extends InputListener 
{
	PlayerActor playerActor;
	
	public InputHandler(PlayerActor playerActor) 
	{
		this.playerActor = playerActor;
	}
	
	@Override
	public boolean keyDown(InputEvent event, int keycode) 
	{
	
		switch (keycode) 
		{
		case Keys.W:
			break;
		case Keys.S:
			break;
		case Keys.A:
			playerActor.setMoveLeft(true);
			break;
		case Keys.D:
			playerActor.setMoveRight(true);
			break;
		default:
			break;
		}
		return true;
	}

	@Override
	public boolean keyUp(InputEvent event, int keycode)
	{
		switch (keycode) {
		case Keys.W:
			break;
		case Keys.S:
			break;
		case Keys.A:
			playerActor.setMoveLeft(false);
			break;
		case Keys.D:
			playerActor.setMoveRight(false);
			break;
		default:
			break;
		}
		return true;
	}
	
}


package com.quakesurvival.game.controls;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Array;
import com.quakesurvival.game.attribute.Item;

/**
 * @brief ���� ������ � ������ �ϴ��� ����
 * @n
 * @author �ǹμ� 
 * @date 2016-12-27
 * @version 1.0.0
 */
public class Slot 
{

	private Item item;

	private int amount;

	private Array<SlotListener> slotListeners = new Array<SlotListener>();

	public Slot(Item item, int amount)
	{
		this.item = item;
		this.amount = amount;
	}

	public boolean isEmpty() 
	{
		return item == null || amount <= 0;
	}

	public void addListener(SlotListener slotListener) 
	{
		slotListeners.add(slotListener);
	}

	public void removeListener(SlotListener slotListener)
	{
		slotListeners.removeValue(slotListener, true);
	}

	public boolean matches(Slot other) 
	{
		return this.item == other.item && this.amount >= other.amount;
	}
	/**
	 * @details ���Կ� �������� �߰��� �� �ִ����� �Ǵ�
	 * @n
	 * @param Item item
	 * @param int amount
	 * @return boolean
	 */
	public boolean add(Item item, int amount) 
	{
		if (this.item == item || this.item == null) 
		{
			this.item = item;
			this.amount += amount;
			System.out.println(this.amount);
			notifyListeners();
			return true;
		}

		return false;
	}
	/**
	 * @details ���Կ��� �������� ���� �ִ����� �Ǵ�
	 * @n
	 * @param Item item
	 * @param int amount
	 * @return boolean
	 */
	public boolean take(int amount) 
	{
		if (this.amount >= amount) 
		{
			this.amount -= amount;
			if (this.amount == 0) 
			{
				item = null;
			}
			System.out.println(this.amount);
			notifyListeners();
			return true;
		}

		return false;
	}

	private void notifyListeners() 
	{
		for (SlotListener slotListener : slotListeners) 
		{
			slotListener.hasChanged(this);
		}
	}

	public Item getItem() 
	{
		return item;
	}

	public int getAmount()
	{
		return amount;
	}
	
	@Override
	public String toString() 
	{
		return "Slot[" + item + ":" + amount + "]";
	}
}

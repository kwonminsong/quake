package com.quakesurvival.game.controls;

public interface SlotListener 
{
	void hasChanged(Slot slot);
}

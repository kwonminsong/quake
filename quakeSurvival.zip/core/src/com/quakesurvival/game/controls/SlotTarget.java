package com.quakesurvival.game.controls;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.utils.DragAndDrop.Payload;
import com.badlogic.gdx.scenes.scene2d.utils.DragAndDrop.Source;
import com.badlogic.gdx.scenes.scene2d.utils.DragAndDrop.Target;
import com.quakesurvival.actors.SlotActor;

/**
 * @brief �κ��丮���� draganddrop�� ����
 * @n
 * @author �ǹμ� 
 * @date 2016-12-27
 * @version 1.0.0
 */
public class SlotTarget extends Target 
{
	private Slot targetSlot;

	public SlotTarget(SlotActor actor) 
	{
		super(actor);
		targetSlot = actor.getSlot();
	
	}

	@Override
	public boolean drag(Source source, Payload payload, float x, float y, int pointer) 
	{
		Slot payloadSlot = (Slot) payload.getObject();
		return true;
	}

	@Override
	public void drop(Source source, Payload payload, float x, float y, int pointer) 
	{
		
	}
}

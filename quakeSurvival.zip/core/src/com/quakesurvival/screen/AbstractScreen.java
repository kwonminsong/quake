package com.quakesurvival.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.Scaling;
import com.quakesurvival.game.*;

public class AbstractScreen implements Screen 
{
	public static final float WIDTH = 800.0F;
	public static final float HEIGHT = 600.0F;
	

	OrthographicCamera camera;
	
	public AbstractScreen()
	{
		
	}
	
	public OrthographicCamera getCamera()
	{
		return camera;
	}
	
	@Override
	public void show() 
	{
		camera = new OrthographicCamera();
	}

	@Override
	public void render(float delta) 
	{
		
	}

	@Override
	public void resize(int width, int height)
	{
		Vector2 size = Scaling.fill.apply(width, height, this.WIDTH, this.HEIGHT);
		float shiftWidth = (this.WIDTH - size.x) / 2;
        float shiftHeight = (this.HEIGHT - size.y) / 2;
        
		camera.setToOrtho(false, size.x, size.y);
        camera.translate(shiftWidth, shiftHeight);
      
	}

	@Override
	public void pause()
	{
		
	}

	@Override
	public void resume()
	{

		
	}

	@Override
	public void hide()
	{

	}

	@Override
	public void dispose()
	{
		
	}

}

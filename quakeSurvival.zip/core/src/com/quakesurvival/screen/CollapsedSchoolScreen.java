package com.quakesurvival.screen;

import java.util.Random;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.utils.DragAndDrop;
import com.quakesurvival.actors.PlayerActor;
import com.quakesurvival.game.Hud;
import com.quakesurvival.game.attribute.CombiInventory;
import com.quakesurvival.game.attribute.FAidInventory;
import com.quakesurvival.game.attribute.Inventory;
import com.quakesurvival.game.controls.Building;
import com.quakesurvival.game.controls.InputHandler;
import com.quakesurvival.windows.CombiInventoryWindow;
import com.quakesurvival.windows.FAidInventoryWindow;
import com.quakesurvival.windows.InventoryWindow;


public class CollapsedSchoolScreen extends AbstractScreen
{
	private World world;
	private Stage stage;
	private Box2DDebugRenderer renderer;
	private PlayerActor playerActor;
	private InventoryWindow inventoryWindow;
	private CombiInventoryWindow combiInventoryWindow;
	private FAidInventoryWindow faidInventoryWindow;
	private Rectangle nextDayButton;
	private Vector3 touchPoint;
	Skin skin = new Skin (Gdx.files.internal("skins/uiskin.json"));
	DragAndDrop dragAndDrop = new DragAndDrop();
	
	public CollapsedSchoolScreen(Stage stage, World world, Box2DDebugRenderer renderer, PlayerActor playerActor)
	{
		this.stage = stage;
		this.world = world;
		this.renderer = renderer;
		this.playerActor = playerActor;
	
		nextDayButton = new Rectangle(800, 600, 100, 100);
		Skin skin = new Skin(Gdx.files.internal("uiskin.json"));
		
		DragAndDrop dragAndDrop = new DragAndDrop();
		inventoryWindow = new InventoryWindow(stage, new Inventory(), dragAndDrop, skin);
		combiInventoryWindow = new CombiInventoryWindow(stage, new CombiInventory(), dragAndDrop, skin);
		stage.addActor(inventoryWindow);
		stage.addActor(combiInventoryWindow);

	}
	
	
	@Override
	public void show()
	{
		super.show();
	}

	private boolean turn = false;
	
	@Override
	public void render(float delta)
	{
		Gdx.gl.glClearColor(0.8F, 1.0F, 1.0F, 1.0F);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		super.getCamera().position.x = playerActor.getX() * SchoolScreen.BoxToWorld;
		super.getCamera().update();
	
		world.step(1.0F / 60.0F, 6, 2);
		Matrix4 cameraCopy = super.getCamera().combined.cpy();
		renderer.render(world, cameraCopy.scl(SchoolScreen.BoxToWorld));
		
		if (Gdx.input.isKeyPressed(Input.Keys.I)) 
		{
				inventoryWindow.setVisible(true);
		}
		if (Gdx.input.isKeyPressed(Input.Keys.F) == true) {
			faidInventoryWindow =new FAidInventoryWindow(stage, new FAidInventory(), dragAndDrop, skin);
			stage.addActor(faidInventoryWindow);
			faidInventoryWindow.setVisible(true);
		}
		
		if (Gdx.input.isKeyPressed(Input.Keys.C)) 
		{
			combiInventoryWindow.setVisible(true);
		}
		
		if (Gdx.input.isKeyPressed(Input.Keys.ESCAPE)) 
		{
			inventoryWindow.setVisible(false);
		}
		
		if (Gdx.input.isKeyPressed(Input.Keys.ESCAPE)) 
		{
			combiInventoryWindow.setVisible(false);
		}
		
		
		
/*		if (Gdx.input.justTouched())
		{
			super.camera.unproject(touchPoint.set(Gdx.input.getX(), Gdx.input.getY(), 0));
			
			
			if (nextDayButton.contains(touchPoint.x, touchPoint.y)) 
			{
				
				return;
			}
		}*/
		
		

	
		stage.act(delta);
		stage.draw();
	}
		
	@Override
	public void resize(int width, int height)
	{
		super.resize(width, height);
	}

	@Override
	public void dispose() 
	{
		world.dispose();
		stage.dispose();
	}	
}
package com.quakesurvival.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.quakesurvival.game.*;

/**
 * 
 * @brief This class is the mainMenuScreen of the game. This class specifies each area through Ractangle, and if you press the specified area, the screen moves according to the name of each Ractangle.
 * @n
 * @author oheong
 *
 */
public class MainMenuScreen extends AbstractScreen
{
	
	QuakeSurvivalGame game;
	Rectangle GameStartButton;
	Rectangle ShowScoreButton;
	Rectangle GoSettingButton;
	Rectangle splashtest;
	
	Vector3 touchPoint;
	Texture backgroundimg;
	Texture GameStartButtonimg;
	Texture ShowScoreButtonimg;
	Texture GoSettingButtonimg;

	public MainMenuScreen(QuakeSurvivalGame game)
	{
		this.game = game;
		GameStartButton = new Rectangle(150, 230, 500, 90);//��ư���� ����
		ShowScoreButton = new Rectangle(150, 130, 500, 90);
		GoSettingButton = new Rectangle(150, 30, 500, 90);
		splashtest = new Rectangle(0, 0, 50, 50);
		
		backgroundimg = new Texture("paris.jpg");
		GameStartButtonimg = new Texture("GameStartButton.jpg");
		ShowScoreButtonimg = new Texture("ShowScoreButton.jpg");
		GoSettingButtonimg = new Texture("GoSettingButton.jpg");
		touchPoint = new Vector3();
	}
	/**@brief brief description of update()
	 * @brief This function is a function that moves to the appropriate screen when a button in the specified area is clicked.
	 * @n
	 * @exception none
	 */
	public void update()
	{
		if (Gdx.input.justTouched())
		{
			super.camera.unproject(touchPoint.set(Gdx.input.getX(), Gdx.input.getY(), 0));
			
			if (GameStartButton.contains(touchPoint.x, touchPoint.y)) 
			{
				game.createSchoolScreen();
				return;
			}
			if (ShowScoreButton.contains(touchPoint.x, touchPoint.y)) 
			{
				//game.splashScreen();
				game.setScoreScreen();
				return;
			}
			if (GoSettingButton.contains(touchPoint.x, touchPoint.y)) 
			{
				game.setSettingScreen();
				return;
			}
		}
	}
	public void draw(){	
		GL20 gl = Gdx.gl;
		gl.glClearColor(0,0,0,0);//red, green, blue, alpha
		gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		super.camera.update();
		
		game.batch.begin();
		game.batch.draw(backgroundimg, 0, 0, 800, 600);// ���ȭ�� �̹���  ��ġ,��ġ,�׸�ũ��,�׸�ũ��


		game.batch.draw(GameStartButtonimg, 150, 230, 500, 90);
		game.batch.draw(ShowScoreButtonimg, 150, 130, 500, 90);
		game.batch.draw(GoSettingButtonimg, 150, 30, 500, 90);
		game.batch.end();
	}
	@Override
	public void render (float delta) {
		update();
		draw();
	}
}

package com.quakesurvival.screen;

import java.util.Random;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.Scaling;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.quakesurvival.game.*;
import com.quakesurvival.game.controls.Building;
import com.quakesurvival.game.controls.InputHandler;
import com.quakesurvival.game.controls.WorldContactHandler;
import com.quakesurvival.actors.PlayerActor;


public class SchoolScreen extends AbstractScreen
{
	public static final float WorldToBox = 0.01F;
	public static final float BoxToWorld = 100.0F;
	
	private World world;
	private Box2DDebugRenderer renderer;
	private Stage stage;
	private Building building;
	private PlayerActor playerActor;
	private InputHandler inputHandler;
	private boolean quakeStart = false, quakeEnd = false;
	private Hud hud;
	private SpriteBatch batch;
	private float timeCount = 0.0F;
	private int countdown = 30;
	private Game game;
	
	
	public SchoolScreen(Game game)
	{
		this.game = game;
		
		world = new World(new Vector2(0.0F, -9.8F), false);	//�߷��� �޴� ���� ����
		world.setContactListener(new WorldContactHandler());
		renderer = new Box2DDebugRenderer();					//�� ��ü���� �׸��� ������	
		
		playerActor = new PlayerActor(world);
		inputHandler = new InputHandler(this.playerActor);
		
		batch = new SpriteBatch();
		hud = new Hud(batch);
	 
		stage = new Stage();
		stage.addListener(this.inputHandler);
		stage.addActor(this.playerActor);
		
		building = new Building(stage, world, 0);
		
		Gdx.input.setInputProcessor(stage);
	}
	
	public int getcountdown()
	{
		return countdown;
	}
	
	@Override
	public void show()
	{
		super.show();
		System.out.println(Gdx.files.internal("icons\\icons.atlas"));
	}

	@Override
	public void render(float delta)
	{
		hud.update(quakeStart, countdown);
		Gdx.gl.glClearColor(1.0F, 1.0F, 1.0F, 1.0F);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		this.stage.act(delta);
		this.stage.draw();

		hud.stage.draw();
		Matrix4 cameraCopy = super.getCamera().combined.cpy();
		
		renderer.render(this.world, cameraCopy.scl(BoxToWorld));
		world.step(1.0F / 60.0F, 6, 2);//FPS 60 ���� �׸���.
		
		timeCount += Gdx.graphics.getDeltaTime();
		if(timeCount >= 1.0F)
		{	
			Random random = new Random();
			if(!quakeStart)
			{	
				if(random.nextFloat() >= 0.9)
				{
					quakeStart = true;
				}
			}
			else if(!quakeEnd)
			{
				if(countdown > 0)
				{
					if(countdown < 10 && !building.isCollapsing())
					{
						building.collapse();
					}
					else if(!building.isCollapsing())
					{
						building.throwDown();
					}
				}
				else
				{
					quakeEnd = true;
					game.setScreen(new CollapsedSchoolScreen(stage, world, renderer, playerActor));
				}
				countdown--;
			}
			else
			{
				
			}
			timeCount = 0;
		}
		
		if(!quakeStart || quakeEnd)
		{
			super.getCamera().position.x = playerActor.getX() * BoxToWorld;
		}
		else
		{
			if(((int) (timeCount * 10)) % 2 == 1)
				super.getCamera().position.x = playerActor.getX() * BoxToWorld - 2;
			else
				super.getCamera().position.x = playerActor.getX() * BoxToWorld + 2;
		}
		super.getCamera().update();
	}
	
	@Override
	public void resize(int width, int height)
	{
		super.resize(width, height);
	}

	@Override
	public void dispose() 
	{
		// TODO Auto-generated method stub
		this.world.dispose();
		this.stage.dispose();
	}
}

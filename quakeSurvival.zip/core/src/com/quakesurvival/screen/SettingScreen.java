package com.quakesurvival.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.quakesurvival.game.QuakeSurvivalGame;

/**
 * @brief This class sets the game difficulty level and background. In this class, clicking on the difficulty and background selection part, the integer value 'setlevel', 'setbackground' variable receives the value, the game background and difficulty level are set.
 * @n
 * @author oheong
 */
public class SettingScreen extends AbstractScreen
{
	QuakeSurvivalGame game;
	SplashScreen splashscreen;
	Rectangle EasyLevel;
	Rectangle HardLevel;
	Rectangle Home;
	Rectangle School;
	Rectangle returnMain;
	
	Vector3 touchPoint;
	Texture EasyLevelimg;
	Texture HardLevelimg;
	Texture Homeimg;
	Texture Schoolimg;
	Texture questionLevel;
	Texture questionBackground;
	Texture returnMainimg;
	
	//����, ��� �������� ���õ� �������� �޾Ƽ� ���ӿ� ����
	int setlevel, setbackground;
	
	public SettingScreen(QuakeSurvivalGame game)
	{
		this.game = game;
		
		returnMain = new Rectangle(0, 0, 60, 60);
		EasyLevel = new Rectangle(200, 300, 150, 100);//��ư���� ����
		HardLevel = new Rectangle(450, 300, 150, 100);
		
		School = new Rectangle(200, 50, 200, 100);
		Home = new Rectangle(450, 50, 150, 100);
		touchPoint = new Vector3();

		returnMainimg = new Texture("return.jpg");
		EasyLevelimg = new Texture("Easy.jpg");
		HardLevelimg = new Texture("Hard.jpg");
		Homeimg = new Texture("Home.jpg");
		Schoolimg = new Texture("School.jpg");
		questionLevel = new Texture("SelectLevel.jpg");
		questionBackground = new Texture("SelectBackground.jpg");

		}
	/**@brief brief description of setLevel()
	 * @brief In this function, you can set the value of the corresponding Rectangle name to the level by pressing the point specified by Rectangle.
	 * @n
	 * @exception none
	 */
	public void setLevel()
	{
		if(Gdx.input.justTouched())
		{
			super.camera.unproject(touchPoint.set(Gdx.input.getX(), Gdx.input.getY(), 0));
			if (EasyLevel.contains(touchPoint.x, touchPoint.y)) 
			{
				setlevel = 0;
				return;
			}
			
			if (HardLevel.contains(touchPoint.x, touchPoint.y)) 
			{
				setlevel = 1;
				return;
			}	
		}
	}
	/**@brief brief description of setBackground()
	 * @brief In this function, you can set the value of the corresponding Rectangle name in the background by pressing the point specified by Rectangle.
	 * @n
	 * @exception none
	 */
	public void setBackground()
	{
		if(Gdx.input.justTouched())
		{
			super.camera.unproject(touchPoint.set(Gdx.input.getX(), Gdx.input.getY(), 0));
			
			if (Home.contains(touchPoint.x, touchPoint.y)) 
			{
				setbackground = 0;
				return;
			}
			
			if (School.contains(touchPoint.x, touchPoint.y))
			{
				setbackground = 1;
				return;
			}
		}
	}
	/**@brief brief description of returnMain()
	 * @brief This function allows you to specify the Rectangle of the button to be used when returning from the Screen showing the Score to the MainMenu, and returning to the MainMenu when pressed.
	 * @n
	 * @exception none
	 */
	public void returnMain()
	{
		if(Gdx.input.justTouched())
		{
			super.camera.unproject(touchPoint.set(Gdx.input.getX(), Gdx.input.getY(), 0));
			if (returnMain.contains(touchPoint.x, touchPoint.y))
			{
				game.setMainMenuScreen();
				return;
			}
		}
	}
	
	@Override
	public void render(float delta){
		Gdx.gl.glClearColor(1.0F, 1.0F, 1.0F, 1.0F);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		game.batch.begin();
		
		game.batch.draw(questionLevel, 100, 450, 350, 60);//Level
		game.batch.draw(EasyLevelimg, 200, 300, 150, 100);
		game.batch.draw(HardLevelimg, 450, 300, 150, 100);
		game.batch.draw(returnMainimg, 0, 0, 60, 60);
		
		game.batch.draw(questionBackground, 100, 200, 350, 60);//Background
		game.batch.draw(Schoolimg, 200, 50, 200, 100);
		game.batch.draw(Homeimg, 450, 50, 150, 100);
		game.batch.end();
		 
		setLevel();
		setBackground();
		returnMain();
		System.out.println("���̵�"+setlevel+"���"+setbackground);
	}
}

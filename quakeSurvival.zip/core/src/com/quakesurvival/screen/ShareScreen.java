package com.quakesurvival.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.ui.CheckBox;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.quakesurvival.game.QuakeSurvivalGame;

public class ShareScreen extends AbstractScreen
{
	private TextButton shareButton;
	private CheckBox breadBox1, breadBox2, breadBox3, waterBox1, waterBox2, waterBox3;
	private Table table;
	public ShareScreen(QuakeSurvivalGame game, Skin skin)
	{
		shareButton = new TextButton("share", skin);
		
		table = new Table();
		table.setFillParent(true);
		
	}
	
	@Override
	public void render (float delta) 
	{
		Gdx.gl.glClearColor(0.8F, 0.9F, 1.0F, 1.0F);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
	}
	
}

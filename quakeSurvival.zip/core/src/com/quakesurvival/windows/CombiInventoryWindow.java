package com.quakesurvival.windows;


import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.Window;
import com.badlogic.gdx.scenes.scene2d.utils.DragAndDrop;
import com.quakesurvival.actors.SlotActor;
import com.quakesurvival.game.attribute.CombiInventory;
import com.quakesurvival.game.controls.CombiClickHandler;
import com.quakesurvival.game.controls.HidingClickHandler;
import com.quakesurvival.game.controls.Slot;
import com.quakesurvival.game.controls.SlotSource;
import com.quakesurvival.game.controls.SlotTarget;

/**
 * @brief ����â�� ������� ��Ÿ����
 * @n
 * @author �ǹμ� 
 * @date 2016-12-27
 * @version 1.0.0
 */

public class CombiInventoryWindow extends Window 
{

	Table buttonTable;
	/**
	 * @details ����â�� ������ �߰��ϰ� ������ ����� �� �ֵ��� butten�� ����
	 * @n
	 * @param Stage stage
	 * @param CombiInventory combiInventory
	 * @param DragAndDrop dragAndDrop
	 * @param Skin skin
	 */
	public CombiInventoryWindow(Stage stage, CombiInventory combiInventory, DragAndDrop dragAndDrop, Skin skin)
	{
		super("Combi", skin);
		
		buttonTable = new Table();
		this.addActor(buttonTable);

		TextButton closeButton = new TextButton("X", skin);
		closeButton.addListener(new HidingClickHandler(this));
		
		
		buttonTable.add(closeButton).height(getPadTop());

		setPosition(0, 180);
		defaults().spaceRight(8);

		int i = 0;
		for (Slot slot : CombiInventory.getSlots()) 
		{
			SlotActor slotActor = new SlotActor(stage, skin, slot);
			dragAndDrop.addSource(new SlotSource(slotActor));
			dragAndDrop.addTarget(new SlotTarget(slotActor));
			add(slotActor);
			Label label = new Label("", skin);
			add(label);

			i++;

			if (i % 2 == 0) 
			{
				row();
				Label label2 = new Label("", skin);
				add(label2);
			}
		}
		row();
		
		Label label1 = new Label("", skin);
		add(label1);
		TextButton combiButton = new TextButton("COMBINATION", skin);
		combiButton.addListener(new CombiClickHandler(this));
		add(combiButton);
		pack();
		setVisible(false);
	}

}

package com.quakesurvival.windows;

import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.Window;
import com.badlogic.gdx.scenes.scene2d.utils.DragAndDrop;
import com.quakesurvival.actors.SlotActor;
import com.quakesurvival.game.attribute.Inventory;
import com.quakesurvival.game.controls.HidingClickHandler;
import com.quakesurvival.game.controls.Slot;
import com.quakesurvival.game.controls.SlotSource;
import com.quakesurvival.game.controls.SlotTarget;

/**
 * @brief �κ��丮�� ������� ��Ÿ����
 * @n
 * @author �ǹμ� 
 * @date 2016-12-27
 * @version 1.0.0
 */
public class InventoryWindow extends Window 
{	/**
	 * @details �κ��丮�� ������ ����
	 * @n
	 * @param Stage stage
	 * @param CombiInventory combiInventory
	 * @param DragAndDrop dragAndDrop
	 * @param Skin skin
	 */
	public InventoryWindow(Stage stage, Inventory inventory, DragAndDrop dragAndDrop, Skin skin) 
	{
		super("Inventory", skin);
		
		TextButton closeButton = new TextButton("X", skin);
		closeButton.addListener(new HidingClickHandler(this));
		this.add(closeButton).height(getPadTop());

		Label label = new Label("", skin);
		add(label);
		setPosition(400, 100);
		defaults().space(8);
		row().fill().expandX();

		int i = 0;
		for (Slot slot : inventory.getSlots()) 
		{
			SlotActor slotActor = new SlotActor(stage, skin, slot);
			dragAndDrop.addSource(new SlotSource(slotActor));
			dragAndDrop.addTarget(new SlotTarget(slotActor));
			add(slotActor);

			i++;
			if (i % 5 == 0) {
				row();
			}
			
		}

		pack();

		setVisible(false);
	}

}

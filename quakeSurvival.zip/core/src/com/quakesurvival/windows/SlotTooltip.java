package com.quakesurvival.windows;

import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Window;
import com.badlogic.gdx.graphics.*;
import com.quakesurvival.game.controls.Slot;
import com.quakesurvival.game.controls.SlotListener;
/**
 * @brief ���Կ� Ŀ���� �����ٴ�� tooltip�� ��Ÿ������ �����Ѵ�.
 * @n
 * @author �ǹμ� 
 * @date 2016-12-27
 * @version 1.0.0
 */

public class SlotTooltip extends Window implements SlotListener
{
	private Skin skin;
	private Slot slot;

	public SlotTooltip(Slot slot, Skin skin) 
	{
		super(" " + slot.getItem(), skin);
		this.slot = slot;
		this.skin = skin;
		hasChanged(slot);
		slot.addListener(this);
		setVisible(false);
	}

	@Override
	public void hasChanged(Slot slot) 
	{
		if (slot.isEmpty()) 
		{
			setVisible(false);
			return;
		}


		Label label = new Label("Super awesome description of " + slot.getItem(), skin);
		add(label);
		pack();
	}

	@Override
	public void setVisible(boolean visible) 
	{
		super.setVisible(visible);
		if (slot.isEmpty()) 
		{
			super.setVisible(false);
		}
	}

}

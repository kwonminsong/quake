/**
 * @file NonPlayerActor.java
 * @brief NonPlayerActor
 */

package com.quakesurvival.actors;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureAtlas.AtlasRegion;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.EdgeShape;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.JointEdge;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.quakesurvival.game.attribute.Assets;
import com.quakesurvival.game.attribute.Survivor;
import com.quakesurvival.screen.SchoolScreen;

public class NonPlayerActor extends Actor 
{

	public Survivor nonPlayer;
	private float velocity;

	public NonPlayerActor(TextureRegion[] faceSet)
	{

		this.velocity = 2.0F;
		this.nonPlayer = new Survivor(faceSet);
		
		
	}
	
	/** @brief delta �ð� ���� �������� Body�� ��ġ �� ������ Actor�� ����ȭ�Ѵ�.
	 * 
	 */
	@Override
	public void act(float delta)
	{	
		super.act(delta);
	}
	
	/** @brief
	 */
	@Override
	public void draw (Batch batch, float parentAlpha)
	{
		super.draw(batch, parentAlpha);
		
	}

	public void die()
	{
		
	}

	

	
}

package com.quakesurvival.game.attribute;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureAtlas.AtlasRegion;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;

public class Assets 
{
	public static TextureAtlas textureAtlas;
	public static TextureRegion[] yoon, kim, choi, icon;
	public static TextureRegion bread0, bread1, water0, water1, nextday0, nextday1, gamestart0, gamestart1, setting0, setting1, score0, score1, return0, return1
								,easy0, easy1, hard0, hard1, title, playerHoldLeft, playerHoldRight, ceiling0, ceiling1, ceiling2, ceiling3, wall, piece, lamp
								,playerDead, npc1, npc2, bowl1;
	public static Animation playerLeftMove, playerRightMove;
	public static Texture mainMenuBackground, bottom, floor, background, building, gameover, rescue;
	public static Skin skin;
	
	public static boolean ishard = false;
	
	public static void load () 
	{
		textureAtlas = new TextureAtlas("textures\\textures.atlas");
		
		bread0 = textureAtlas.findRegion("bread0");
		bread1 = textureAtlas.findRegion("bread1");
		water0 = textureAtlas.findRegion("water0");
		water1 = textureAtlas.findRegion("water1");
		
		nextday0 = textureAtlas.findRegion("nextday0");
		nextday1 = textureAtlas.findRegion("nextday1");
		
		gamestart0 = textureAtlas.findRegion("gamestart0");
		gamestart1 = textureAtlas.findRegion("gamestart1");
		setting0 = textureAtlas.findRegion("setting0");
		setting1 = textureAtlas.findRegion("setting1");
		score0 = textureAtlas.findRegion("score0");
		score1 = textureAtlas.findRegion("score1");
		return0 = textureAtlas.findRegion("return0");
		return1 = textureAtlas.findRegion("return1");
		easy0 = textureAtlas.findRegion("easy0");
		easy1 = textureAtlas.findRegion("easy1");
		hard0 = textureAtlas.findRegion("hard0");
		hard1 = textureAtlas.findRegion("hard1");
		title = textureAtlas.findRegion("title");
		
		bowl1 = textureAtlas.findRegion("bowl");
		
		yoon = new TextureRegion[3];
		for(int i = 0; i < yoon.length; i++)
		{
			yoon[i] = textureAtlas.findRegion("yoon" + i);
		}
		
		kim = new TextureRegion[3];
		for(int i = 0; i < kim.length; i++)
		{
			kim[i] = textureAtlas.findRegion("kim" + i);
		}
		
		choi = new TextureRegion[3];
		for(int i = 0; i< choi.length; i++)
		{
			choi[i] = textureAtlas.findRegion("choi" + i);
		}
		
		ceiling0 = textureAtlas.findRegion("ceiling0");
		ceiling1 = textureAtlas.findRegion("ceiling1");
		ceiling2 = textureAtlas.findRegion("ceiling2");
		ceiling3 = textureAtlas.findRegion("ceiling3");
		wall = textureAtlas.findRegion("wall");
		piece = textureAtlas.findRegion("piece");
		lamp = textureAtlas.findRegion("lamp");
		
		npc1 = textureAtlas.findRegion("npc1");
		npc2 = textureAtlas.findRegion("npc2");
		
		playerHoldLeft = textureAtlas.findRegion("pcl0");
		playerHoldRight = textureAtlas.findRegion("pc0");
		playerDead = textureAtlas.findRegion("pcdead");
		playerLeftMove = new Animation(0.1f, textureAtlas.findRegion("pcl0"), textureAtlas.findRegion("pcl1"), textureAtlas.findRegion("pcl2"), textureAtlas.findRegion("pcl3"), textureAtlas.findRegion("pcl4"), textureAtlas.findRegion("pcl5"));
		playerRightMove = new Animation(0.1f, textureAtlas.findRegion("pc0"), textureAtlas.findRegion("pc1"), textureAtlas.findRegion("pc2"), textureAtlas.findRegion("pc3"), textureAtlas.findRegion("pc4"), textureAtlas.findRegion("pc5"));
		
		mainMenuBackground = new Texture(Gdx.files.internal("main.jpg"));
		bottom = new Texture(Gdx.files.internal("bottom.png"));
		floor = new Texture(Gdx.files.internal("floor.png"));
		background = new Texture(Gdx.files.internal("background.jpg"));
		building = new Texture(Gdx.files.internal("building.jpg"));
		gameover = new Texture(Gdx.files.internal("gameover.png"));
		rescue = new Texture(Gdx.files.internal("rescue.png"));
		
//		skin = new Skin(Gdx.files.internal("data/uiskin.json"));
		
	}
}

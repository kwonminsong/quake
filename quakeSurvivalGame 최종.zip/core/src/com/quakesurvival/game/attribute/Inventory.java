/**
 * @file Inventory.java
 * @brief Inventory
 */


package com.quakesurvival.game.attribute;

import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.Array;
import com.quakesurvival.game.controls.Slot;

/**
 * @brief �κ��丮�� ������ �����ϰ�, �κ��丮���� � �۾��� �ϴ��� �����Ѵ�.
 * @n
 * @author �ǹμ� 
 * @date 2016-12-27
 * @version 1.0.0
 */
public class Inventory 
{
	private Array<Slot> slots;
	/**
	 * @details �κ��丮�� ����
	 * @n
	 */
	public Inventory() 
	{
		slots = new Array<Slot>(25);
		for (int i = 0; i < 25; i++) {
			slots.add(new Slot(null, 0));
		}
		
		/*
		for (Slot slot : slots) 
		{
			slot.add(Item.values()[MathUtils.random(0, 5)], 1);
		}
		 */
		slots.get(0).add(Item.PLASTIC_BOTTLE, 1);
		slots.get(1).add(Item.SCISSORS, 1);
		slots.get(2).add(Item.BATTERY, 1);
		slots.get(3).add(Item.NOTBATTERYFLASHLIGHT, 1);
		slots.get(4).add(Item.NEWSPAPER, 1);
		slots.get(5).add(Item.PLASTIC_BAG, 1);
		
	}

	/** @brief
	 */
	public int checkInventory(Item item) 
	{
		int amount = 0;

		for (Slot slot : slots) 
		{
			if (slot.getItem() == item) 
			{
				amount += slot.getAmount();
			}
		}

		return amount;
	}
	/**
	 * @details �������� �߰�
	 * @n
	 * @param Item item
	 * @param int amount
	 * @return boolean
	 */
	public boolean store(Item item, int amount) 
	{
	
		Slot itemSlot = firstItem(item);
		if (itemSlot != null)
		{
			itemSlot.add(item, amount);
			return true;
		} 
		else 
		{
			Slot emptySlot = firstItem(null);
			if (emptySlot != null)
			{
				emptySlot.add(item, amount);
				return true;
			}
		}


		return false;
	}

	/** @brief
	 */
	public Array<Slot> getSlots() 
	{
		return slots;
	}

	/** @brief
	 */
	private Slot firstItem(Item item)
	{
		for (Slot slot : slots)
		{
			if (slot.getItem() == item) 
			{
				return slot;
			}
		}

		return null;
	}
	
	public String[] getItemList()
	{
		String[] itemList = new String[25];
		
		for(int i =0; i< 25; i++)
		{
			if(this.getSlots().get(i).getItem() != null)
			{
				itemList[i] = this.getSlots().get(i).getItem().getTextureRegion();
			}
		}
		
		return itemList;
	}

}

/**
 * @file Supplies.java
 * @brief Supplies
 */

package com.quakesurvival.game.attribute;

/**
 * @brief Supplies Ŭ����
 * @details ���ڷ� ������ �����ϰ� �ִ� Ŭ����
 * @author �̾�ȣ
 * @version 1.0.0
 **/
public class Supplies 
{
	private int bread, water;
	
	/** @brief
	 */
	public Supplies(int bread, int water)
	{
		this.bread = bread;
		this.water = water;
	}
	
	/** @brief
	 */
	public boolean consume(int bread, int water)
	{
		if(this.bread < bread || this.water < water)
		{
			return false;
		}
		
		this.bread -= bread;
		this.water -= water;
	
		return true;
	}
	
	public int getBread()
	{
		return bread;
	}
	
	public int getWater()
	{
		return water;
	}
	
	public void addWater(int water)
	{
		this.water += water;
	}

}

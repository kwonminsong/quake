/**
 * @file Survivor.java
 * @brief Survivor
 */

package com.quakesurvival.game.attribute;

import com.badlogic.gdx.graphics.g2d.TextureRegion;

/**
 * @brief Survivor Ŭ����
 * @details Player �� Non-Player�� ���� ������ �����ϴ� Ŭ����
 * @author �̾�ȣ
 * @version 1.0.0
 */
public class Survivor
{
	public static final int MAX_HUNGRY = 21;
	public static final int MIN_HUNGRY = 0;
	public static final int MAX_THIRST = 3;
	public static final int MIN_THIRST = 0;
	public static final float MAX_TEMPERTURE = 40.0F;
	public static final float MIN_TEMPERTURE = 26.5F;
	
	public static enum Feeling{despair, normal, hope};
	
	private boolean isDead = false;

	private Feeling feeling;
	private int hungry, thirst;
	private float temperture;
	private TextureRegion[] faceSet;
	private TextureRegion face;
	
	/** @brief
	 */
	public Survivor(TextureRegion[] faceSet)
	{
		feeling = Feeling.normal;
		this.temperture = 36.5F;
		this.hungry = 1;
		this.thirst = 1;
		this.faceSet = faceSet;
		face = faceSet[1];
		
	}
	
	/** @brief
	 */
	public void eat()
	{
		hungry -= 3;
		if(hungry < MIN_HUNGRY)
			hungry = 0;
	}
	
	public void drink()
	{
		thirst -= 2;
		if(thirst < MIN_THIRST)
			thirst = 0;
	}
	
	public boolean update()
	{
		hungry += 1;
		thirst += 1;
		
		if(hungry > MAX_HUNGRY || thirst > MAX_THIRST)
		{
			face = faceSet[0];
			isDead = true;
		}
		else if(hungry < 4)
		{
			face = faceSet[1];
		}
		else
		{
			face = faceSet[2];
		}
		
		return isDead;
	}
	
	public boolean checkDead()
	{
		return isDead;
		
	}
	
	public TextureRegion showFace()
	{
		return face;
	}
	
	/** @brief
	 */
	public int getHungry()
	{
		return hungry;
	}
	
	/** @brief
	 */
	public int getThirst()
	{
		return thirst;
	}
	
	/** @brief
	 */
	public float getTemperture()
	{
		return temperture;
	}
	
	public void setDespair()
	{
		feeling = Feeling.despair;
	}
	
}
	
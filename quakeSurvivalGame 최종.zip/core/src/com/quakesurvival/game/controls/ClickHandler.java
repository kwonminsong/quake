package com.quakesurvival.game.controls;

import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.quakesurvival.screen.CollapsedSchoolScreen;
import com.quakesurvival.screen.ShareScreen;

public class ClickHandler extends ClickListener 
{
	
	private CollapsedSchoolScreen collapsedSchoolScreen;
	private ShareScreen shareScreen;
	public ClickHandler(CollapsedSchoolScreen collapsedSchoolScreen)
	{
		this.collapsedSchoolScreen = collapsedSchoolScreen;
	}

	/** @brief
	 */
	@Override
	public void clicked(InputEvent event, float x, float y) 
	{
		collapsedSchoolScreen.setShareScreen();
	}
	
}
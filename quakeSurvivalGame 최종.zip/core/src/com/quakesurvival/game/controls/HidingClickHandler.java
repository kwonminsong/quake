/**
 * @file HidingClickHandler.java
 * @brief HidingClickHandler
 */

package com.quakesurvival.game.controls;


import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Window;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

public class HidingClickHandler extends ClickListener 
{
	private Actor actor;

	/** @brief
	 */
	public HidingClickHandler(Actor actor) 
	{
		this.actor = actor;
	}
	
	/** @brief
	 */
	@Override
	public void enter (InputEvent event, float x, float y, int pointer, Actor fromActor) 
	{
		Window window = (Window) actor;
		window.setMovable(false);
	}
	
	/** @brief
	 */
	@Override
	public void exit (InputEvent event, float x, float y, int pointer, Actor toActor) 
	{
		Window window = (Window) actor;
		window.setMovable(true);
	}

	/** @brief
	 */
	@Override
	public void clicked(InputEvent event, float x, float y) 
	{
		actor.setVisible(false);
	}

}

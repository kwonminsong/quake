/**
 * @file SlotListener.java
 * @brief SlotListener 
 */

package com.quakesurvival.game.controls;

public interface SlotListener 
{
	/** @brief
	 */
	void hasChanged(Slot slot);
}

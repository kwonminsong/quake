/**
 * @file SlotSource.java
 * @brief SlotSource
 */


package com.quakesurvival.game.controls;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.DragAndDrop.Payload;
import com.badlogic.gdx.scenes.scene2d.utils.DragAndDrop.Source;
import com.badlogic.gdx.scenes.scene2d.utils.DragAndDrop.Target;
import com.quakesurvival.actors.SlotActor;
import com.quakesurvival.game.attribute.Assets;
import com.quakesurvival.game.attribute.Item;

/**
 * @brief �κ��丮���� draganddrop�� ����
 * @n
 * @author �ǹμ� 
 * @date 2016-12-27
 * @version 1.0.0
 */
public class SlotSource extends Source 
{
	private Slot sourceSlot;

	public SlotSource(SlotActor actor) 
	{
		super(actor);
		this.sourceSlot = actor.getSlot();
	}
	/**
	 * @details drag����� drag�� �����ϸ� ��� �����ϴ����� ����
	 * @n
	 */
	@Override
	public Payload dragStart(InputEvent event, float x, float y, int pointer) 
	{
		if (sourceSlot.getAmount() == 0)
		{
			return null;
		}

		Payload payload = new Payload();
		Slot payloadSlot = new Slot(sourceSlot.getItem(), sourceSlot.getAmount());
		sourceSlot.take(sourceSlot.getAmount());
		payload.setObject(payloadSlot);

		TextureAtlas icons = Assets.textureAtlas;
		TextureRegion icon = icons.findRegion(payloadSlot.getItem().getTextureRegion());

		Actor dragActor = new Image(icon);
		payload.setDragActor(dragActor);

		return payload;
	}
	/**
	 * @details drag����� drag�� stop�ϸ� ��� �����ϴ����� ����
	 * @n
	 */
	@Override
	public void dragStop(InputEvent event, float x, float y, int pointer, Payload payload, Target target) 
	{
		Slot payloadSlot = (Slot) payload.getObject();
		if (target != null) 
		{
			Slot targetSlot = ((SlotActor) target.getActor()).getSlot();
			if (targetSlot.getItem() == payloadSlot.getItem() || targetSlot.getItem() == null)
			{
				targetSlot.add(payloadSlot.getItem(), payloadSlot.getAmount());
			} 
			
			else 
			{
				Item targetType = targetSlot.getItem();
				int targetAmount = targetSlot.getAmount();
				targetSlot.take(targetAmount);
				targetSlot.add(payloadSlot.getItem(), payloadSlot.getAmount());
				sourceSlot.add(targetType, targetAmount);
			}
		} 
		else 
		{
			sourceSlot.add(payloadSlot.getItem(), payloadSlot.getAmount());
		}
	}
}

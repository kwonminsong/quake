/**
 * @file WorldContactHandler.java
 * @brief WorldContactHandler
 */

package com.quakesurvival.game.controls;

import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.Manifold;
import com.quakesurvival.actors.PlayerActor;

/**
 * @brief WorldContactHandler Ŭ����
 * @details Player Character�� Building�� �� ������ ��ü�� ���� �浹�� �����ϴ� Handler Ŭ���� �̴�.
 * @author �̾�ȣ
 * @version 1.0.0
 */
public class WorldContactHandler implements ContactListener
{

	/** @brief
	 */
	@Override
	public void beginContact(Contact contact) 
	{
		Body a = contact.getFixtureA().getBody();
		
		
		if(a.getUserData() instanceof PlayerActor)
		{
			PlayerActor playerActor = (PlayerActor) a.getUserData();
			
			if(!playerActor.tgm)
			{
				playerActor.die();
			}
			
		}
	}

	/** @brief
	 */
	@Override
	public void endContact(Contact contact) 
	{
		// TODO Auto-generated method stub
		
	}

	/** @brief
	 */
	@Override
	public void preSolve(Contact contact, Manifold oldManifold) 
	{
		// TODO Auto-generated method stub
		
	}

	/** @brief
	 */
	@Override
	public void postSolve(Contact contact, ContactImpulse impulse) 
	{
		// TODO Auto-generated method stub
		
	}

}

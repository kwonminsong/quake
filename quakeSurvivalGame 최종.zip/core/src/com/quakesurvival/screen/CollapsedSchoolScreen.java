/**
 * @file CollpasedSchoolScreen.java
 * @brief CollpasedSchoolScreen
 */

package com.quakesurvival.screen;

import java.util.Random;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator.FreeTypeFontParameter;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.utils.DragAndDrop;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.quakesurvival.actors.NonPlayerActor;
import com.quakesurvival.actors.PlayerActor;
import com.quakesurvival.game.QuakeSurvivalGame;
import com.quakesurvival.game.attribute.Assets;
import com.quakesurvival.game.attribute.CombiInventory;
import com.quakesurvival.game.attribute.Inventory;
import com.quakesurvival.game.attribute.Item;
import com.quakesurvival.game.attribute.Supplies;
import com.quakesurvival.game.attribute.Survivor;
import com.quakesurvival.game.controls.Building;
import com.quakesurvival.game.controls.ClickHandler;
import com.quakesurvival.windows.CombiInventoryWindow;
import com.quakesurvival.windows.InventoryWindow;
import com.quakesurvival.windows.FAidInventoryWindow;
import com.quakesurvival.game.attribute.FAidInventory;

/**
 * @brief ���� ������ ���� ��Ȳ�� ǥ���ϴ� Screen Ŭ����
 * @details ���� ������ ���� ��Ȳ���� ���� �й� �� �ڿ� Ž��, ���� ��� ���� ȣ�� �� �����ϴ� Ŭ�����̴�.
 * @author �̾�ȣ
 * @version 1.0.0
 */
public class CollapsedSchoolScreen extends InGameScreen
{
	private SpriteBatch batch;
	private QuakeSurvivalGame game;
	private Stage stage;
	private ShareScreen shareScreen;
	private PlayerActor playerActor;
	private Building building;
	private NonPlayerActor nonPlayerActor1, nonPlayerActor2;
	private InventoryWindow inventoryWindow;
	private CombiInventoryWindow combiInventoryWindow;
	private FAidInventoryWindow faidInventoryWindow;
	private ImageButton nextButton;
	private Inventory inventory;
	private CombiInventory combiInventory;
	private Label label;
	private int days = 0;
	boolean daily = false;
	private Supplies supplies;
	private Skin skin;
	private DragAndDrop dragAndDrop;
	
	/**  
	 * @brief �� �Ķ���ʹ� SchoolScreen������ ��� ������ �״�� �����޴´�.
	 */
	public CollapsedSchoolScreen(QuakeSurvivalGame game, Stage stage, World world, Box2DDebugRenderer renderer, PlayerActor playerActor, Building building)
	{
		super(world, renderer);
		this.game = game;
		this.stage = stage;
		this.playerActor = playerActor;
		this.building = building;
		

		
		FreeTypeFontGenerator generator = new FreeTypeFontGenerator(Gdx.files.internal("fonts\\koverwatch.ttf"));
		FreeTypeFontParameter parameter = new FreeTypeFontParameter();
	    
		parameter.characters = "�ǹ������ν����������޾Ƴ½��ϴ�.�������޾Ƴ�������";
	    parameter.size = 50;
	    parameter.borderColor = Color.BLACK;
        parameter.borderWidth = 3.0F;
        
	    BitmapFont font = generator.generateFont(parameter);

	    
	    label = new Label("", new Label.LabelStyle(font, Color.ORANGE));
	    label.setPosition(350, 300);
	   
	    stage.addActor(label);
	  
        
		dragAndDrop = new DragAndDrop();
		skin = new Skin(Gdx.files.internal("uiskin.json"));
		
		supplies = new Supplies(10, 10);
		
		batch = new SpriteBatch();
		nonPlayerActor1 = new NonPlayerActor(Assets.kim);
		nonPlayerActor2 = new NonPlayerActor(Assets.choi);
		
		Survivor[] survivors = new Survivor[3];
		survivors[0] = playerActor.player;
		survivors[1] = nonPlayerActor1.nonPlayer;
		survivors[2] = nonPlayerActor2.nonPlayer;
		
		shareScreen = new ShareScreen(game, this, skin, survivors, supplies);

		inventory = new Inventory();
		combiInventory = new CombiInventory();
		
		inventoryWindow = new InventoryWindow(stage, inventory, dragAndDrop, skin);
		combiInventoryWindow = new CombiInventoryWindow(stage, combiInventory, dragAndDrop, skin);
		
		TextureRegionDrawable nextday0 = new TextureRegionDrawable(Assets.nextday0);
		TextureRegionDrawable nextday1 = new TextureRegionDrawable(Assets.nextday1);
		nextButton = new ImageButton(nextday1, nextday1, nextday1);
		nextButton.setPosition(625, 25);
		nextButton.addListener(new ClickHandler(this));

		stage.addActor(nextButton);
		stage.addActor(inventoryWindow);
		stage.addActor(combiInventoryWindow);
	}

	public void setShareScreen()
	{
		game.setScreen(shareScreen);
	}
	
	private void updateState()
	{
		if(playerActor.player.update())
		{
			playerActor.die();
			this.dispose();

			game.setScreen(new GameOverScreen(game));
		}
		
		if(nonPlayerActor1.nonPlayer.update())
		{
			nonPlayerActor1.die();
			playerActor.player.setDespair();
		}
		
		if(nonPlayerActor2.nonPlayer.update())
		{
			nonPlayerActor2.die();
			playerActor.player.setDespair();
		}
		
	}
	/** @brief ������ ���ڸ� ī��Ʈ�ϱ� ���� ��� �Լ��̴�. ������ Random() �Լ��� ���� Ȯ�������� �Ͼ��.
	 * 
	 */
	@Override
	public void show()
	{
		super.show();
		Gdx.input.setInputProcessor(stage);

		if(daily)
		{
			days++;
			
			String[] itemList = inventory.getItemList();
			
			label.getColor().a = 1F;
			for(int i = 0; i < itemList.length; i++)
			{
				String bowl = new String("bowl");
				System.out.println(itemList[i]);
				if(itemList[i] != null && itemList[i].equals("bowl"))
				{
					
					System.out.println("OK");
					Random random = new Random();
					int water = random.nextInt(3);
					if(water == 0)
					{
						 label.setAlignment(Align.center);
						label.setText("������ ������ �޾Ƴ��� ���߽��ϴ�...");
						label.addAction(Actions.sequence(Actions.delay(2.0F), Actions.fadeOut(0.75F)));
					}
					else
					{
						 label.setAlignment(Align.center);
						supplies.addWater(water);
						label.setText("�ǹ� ������ ����� ������ �޾Ƴ½��ϴ�.");
						label.addAction(Actions.sequence(Actions.delay(2.0F), Actions.fadeOut(0.75F)));
						
					}
				
					
					
				}
			}
			
			updateState();
			Random random = new Random();
			System.out.println(days + "����");
			
			if(random.nextFloat() >= 0.8F)
			{
				game.setScreen(new RescueScreen(game));	
				return;
			}
			
			daily = false;
		}
	}



	/** @brief
	 */
	@Override
	public void render(float delta)
	{
		Gdx.gl.glClearColor(0.8F, 1.0F, 1.0F, 1.0F);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		batch.setProjectionMatrix(super.getCamera().combined);
		batch.begin();
		batch.draw(Assets.background, -800.0F, 0.0F);
		batch.draw(Assets.building, -210.0F, 0.0F);
		building.draw(batch);
		if(!nonPlayerActor1.nonPlayer.checkDead())
			batch.draw(Assets.npc2, -180.0F, 60.0F);
		if(!nonPlayerActor2.nonPlayer.checkDead())
			batch.draw(Assets.npc1, -60.0F, 60.0F);
		batch.end();

		
		super.getCamera().position.x = playerActor.getX() * SchoolScreen.BoxToWorld;
		super.getCamera().update();
	
		super.getWorld().step(1.0F / 60.0F, 6, 2);
		Matrix4 cameraCopy = super.getCamera().combined.cpy();
		super.getRenderer().render(super.getWorld(), cameraCopy.scl(SchoolScreen.BoxToWorld));
		
		if (Gdx.input.isKeyPressed(Input.Keys.I)) 
		{
			inventoryWindow.setVisible(true);
		}
		
		if (Gdx.input.isKeyPressed(Input.Keys.C)) 
		{
			combiInventoryWindow.setVisible(true);
		}
		if (Gdx.input.isKeyPressed(Input.Keys.F) == true) 
			{
			faidInventoryWindow =new FAidInventoryWindow(stage, new FAidInventory(), dragAndDrop, skin);
			stage.addActor(faidInventoryWindow);
			faidInventoryWindow.setVisible(true);
		}
		
		if (Gdx.input.isKeyPressed(Input.Keys.ESCAPE)) 
		{
			inventoryWindow.setVisible(false);
			combiInventoryWindow.setVisible(false);
		}

		stage.act(delta);
		stage.draw();
	}
		
	/** @brief
	 */
	@Override
	public void resize(int width, int height)
	{
		super.resize(width, height);
	}

	/** @brief
	 */
	@Override
	public void dispose() 
	{
//		stage.dispose();
//		super.dispose();
	}	
}
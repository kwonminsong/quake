package com.quakesurvival.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator.FreeTypeFontParameter;
import com.badlogic.gdx.scenes.scene2d.Action;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Scaling;
import com.quakesurvival.game.QuakeSurvivalGame;
import com.quakesurvival.game.attribute.Assets;

public class DayScreen extends AbstractScreen 
{
	private CollapsedSchoolScreen collapsedSchoolScreen;
	private QuakeSurvivalGame game;
	private Stage stage;
	private Label dayLabel;
	private int days;

	public DayScreen(QuakeSurvivalGame game, CollapsedSchoolScreen collapsesdSchoolScreen, int days) 
	{
		this.game = game;
		stage = new Stage();
		this.days = days;
		this.collapsedSchoolScreen = collapsesdSchoolScreen;
	}

	@Override
	public void show() 
	{
		super.show();

		
		
	    FreeTypeFontGenerator generator = new FreeTypeFontGenerator(Gdx.files.internal("fonts\\koverwatch.ttf"));
	    FreeTypeFontParameter parameter = new FreeTypeFontParameter();
	        
	    parameter.characters = "0123456789����";
	    parameter.size = 100;
	       
	    parameter.borderColor = Color.GRAY;
	    parameter.borderWidth = 1.0F;
	    BitmapFont font = generator.generateFont(parameter);

	    dayLabel = new Label(days + " ����", new Label.LabelStyle(font, Color.WHITE));
		dayLabel.setPosition(400, 300);
		dayLabel.setAlignment(Align.center);

		dayLabel.getColor().a = 0.0F;

		dayLabel.addAction(Actions.sequence(Actions.fadeIn(0.75f), Actions.delay(1.75f), Actions.fadeOut(0.75f), new Action() 
		{
				@Override
				public boolean act(float delta) 
				{
					game.setScreen(collapsedSchoolScreen);
					return false;
				}
		}));
		
		stage.addActor(dayLabel);
		
	}
	
	@Override
	public void render (float delta)
	{
		GL20 gl = Gdx.gl;
		gl.glClearColor(0, 0, 0, 1);
		gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		super.camera.update();
		stage.act();
		stage.draw();
	}

}

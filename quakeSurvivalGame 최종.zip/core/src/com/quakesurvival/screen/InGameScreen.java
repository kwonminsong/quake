package com.quakesurvival.screen;

import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.World;

public class InGameScreen extends AbstractScreen
{
	private World world;
	private Box2DDebugRenderer renderer;
	
	
	public InGameScreen(World world, Box2DDebugRenderer renderer)
	{
		this.world = world;
		this.renderer = renderer;
	}
	
	public World getWorld()
	{
		return world;
	}
	
	public Box2DDebugRenderer getRenderer()
	{
		return renderer;
	}
	
	@Override
	public void dispose()
	{

//		world.dispose();
//		renderer.dispose();
//		super.dispose();
	}
}

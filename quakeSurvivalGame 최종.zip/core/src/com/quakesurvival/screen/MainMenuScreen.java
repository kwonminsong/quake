/**
 * @file MainMenuScreen.java
 * @brief MainMenuScreen
 */

package com.quakesurvival.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.quakesurvival.game.*;
import com.quakesurvival.game.attribute.Assets;

/**
 * 
 * @brief This class is the mainMenuScreen of the game. This class specifies each area through Ractangle, and if you press the specified area, the screen moves according to the name of each Ractangle.
 * @n
 * @author oheong
 *
 */
public class MainMenuScreen extends AbstractScreen
{
	
	
	private QuakeSurvivalGame game;
	private Table table;
	private ImageButton gameStartButton, showScoreButton, settingButton;
	private Stage stage;	
	private Image backgroundImg;
	private float backgroundVelocity = 0.1f;
	
	public MainMenuScreen(final QuakeSurvivalGame game)
	{
		
		
		this.game = game;
		stage = new Stage();
		
		Image title = new Image(Assets.title);
		title.setPosition(100, 350);
		
		TextureRegionDrawable gamestart0 = new TextureRegionDrawable(Assets.gamestart0);
		TextureRegionDrawable gamestart1 = new TextureRegionDrawable(Assets.gamestart1);
		TextureRegionDrawable score0 = new TextureRegionDrawable(Assets.score0);
		TextureRegionDrawable score1 = new TextureRegionDrawable(Assets.score1);
		TextureRegionDrawable setting0 = new TextureRegionDrawable(Assets.setting0);
		TextureRegionDrawable setting1 = new TextureRegionDrawable(Assets.setting1);
		gameStartButton = new ImageButton(gamestart0, gamestart0, gamestart1);
		showScoreButton = new ImageButton(score0, score0, score1);
		settingButton = new ImageButton(setting0, setting0, setting1);
		
		gameStartButton.addListener(new ClickListener() 
		{
			@Override
			public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor)
			{
				gameStartButton.setChecked(true);
			}
			
			@Override
			public void exit(InputEvent event, float x, float y, int pointer, Actor fromActor)
			{
				gameStartButton.setChecked(false);
			}
			
			@Override
			public void clicked(InputEvent event, float x, float y)
			{
				game.createSchoolScreen();
			}	
		});
		
		showScoreButton.addListener(new ClickListener() 
		{
			@Override
			public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor)
			{
				showScoreButton.setChecked(true);
			}
			
			@Override
			public void exit(InputEvent event, float x, float y, int pointer, Actor fromActor)
			{
				showScoreButton.setChecked(false);
			}
			
			@Override
			public void clicked(InputEvent event, float x, float y)
			{
				game.setScoreScreen();
			}	
		});
		
		settingButton.addListener(new ClickListener() 
		{
			@Override
			public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor)
			{
				settingButton.setChecked(true);
			}
			
			@Override
			public void exit(InputEvent event, float x, float y, int pointer, Actor fromActor)
			{
				settingButton.setChecked(false);
			}
			
			@Override
			public void clicked(InputEvent event, float x, float y)
			{
				game.setSettingScreen();
			}	
		});
		
		
		
		table = new Table();
		table.setBounds(250, 20, 300, 360);
		table.add(gameStartButton).center();
		table.row();
		table.add(showScoreButton).center();
		table.row();
		table.add(settingButton).center();

		backgroundImg = new Image(Assets.mainMenuBackground);
		backgroundImg.setPosition(-200, -200);

		stage.addActor(backgroundImg);
		stage.addActor(table);
		stage.addActor(title);
		
		Gdx.input.setInputProcessor(stage);
	}

	@Override
	public void show()
	{
		Gdx.input.setInputProcessor(stage);
	}

	@Override
	public void render (float delta)
	{
		GL20 gl = Gdx.gl;
		gl.glClearColor(0, 0, 0, 1);
		gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		super.camera.update();
		if(backgroundImg.getX() >= 0)
		{
			backgroundVelocity = -0.1F;
			
		}
		else if(backgroundImg.getX() <= -200)
		{
			backgroundVelocity = 0.1F;
		}
		
		backgroundImg.moveBy(backgroundVelocity, 0);
		stage.act();
		stage.draw();
	}
}

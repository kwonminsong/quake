package com.quakesurvival.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Action;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Scaling;
import com.quakesurvival.game.QuakeSurvivalGame;
import com.quakesurvival.game.attribute.Assets;

public class RescueScreen extends AbstractScreen 
{
	private QuakeSurvivalGame game;
	private Stage stage;
	private Image image;

	public RescueScreen(QuakeSurvivalGame game) 
	{
		this.game = game;
		stage = new Stage();

		Gdx.input.setInputProcessor(stage);
		
	}

	@Override
	public void show() 
	{
		super.show();
		Drawable rescueDrawable = new TextureRegionDrawable(new TextureRegion(Assets.rescue));
		image = new Image(rescueDrawable, Scaling.stretch);
		image.setFillParent(true);

		image.getColor().a = 0f;

		image.addAction(Actions.sequence(Actions.fadeIn(1.75f), Actions.delay(2.75f), Actions.fadeOut(1.75f), new Action() 
		{
				@Override
				public boolean act(float delta) 
				{
					game.setMainMenuScreen();
					return false;
				}
		}));
		
		stage.addActor(image);
		
	}
	
	@Override
	public void render (float delta)
	{
		GL20 gl = Gdx.gl;
		gl.glClearColor(0, 0, 0, 1);
		gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		super.camera.update();
		stage.act();
		stage.draw();
	}

}

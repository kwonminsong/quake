/**
 * @file SchoolScreen.java
 * @brief SchoolScreen
 */

package com.quakesurvival.screen;

import java.util.Random;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.Scaling;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.quakesurvival.game.*;
import com.quakesurvival.game.attribute.Assets;
import com.quakesurvival.game.controls.Building;
import com.quakesurvival.game.controls.InputHandler;
import com.quakesurvival.game.controls.WorldContactHandler;
import com.quakesurvival.actors.PlayerActor;

/**
 * @brief SchoolScreen Ŭ����
 * @details ������ �߻��ϴ� ��Ȳ�� ǥ���ϴ� Screen Ŭ����
 * @author �̾�ȣ
 * @version 1.0.0
 */
public class SchoolScreen extends InGameScreen
{
	public static final float WorldToBox = 0.01F;
	public static final float BoxToWorld = 100.0F;

	private Stage stage;
	private Building building;
	private PlayerActor playerActor;
	private InputHandler inputHandler;
	private boolean quakeStart = false, quakeEnd = false;
	private Hud hud;
	private SpriteBatch batch;
	private float timeCount = 0.0F;
	private int countdown = 30;
	private QuakeSurvivalGame game;
	
	
	/** @brief
	 */
	public SchoolScreen(QuakeSurvivalGame game)
	{
		super(new World(new Vector2(0.0F, -9.8F), false), new Box2DDebugRenderer());
		
		this.game = game;
		
		super.getWorld().setContactListener(new WorldContactHandler());					///< �� ��ü���� �׸��� ������	
		
		playerActor = new PlayerActor(getWorld());
		inputHandler = new InputHandler(this.playerActor);
		
		batch = new SpriteBatch();
		hud = new Hud(batch);
	 
		stage = new Stage();
		stage.addListener(this.inputHandler);
		stage.addActor(this.playerActor);
		
		building = new Building(stage, super.getWorld(), 0);
		
		Gdx.input.setInputProcessor(stage);
	}
	
	public int getcountdown()
	{
		return countdown;
	}
	
	/** @brief
	 */
	@Override
	public void show()
	{
		super.show();
	}

	@Override
	public void render(float delta)
	{
		Gdx.gl.glClearColor(1.0F, 1.0F, 1.0F, 1.0F);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		batch.setProjectionMatrix(super.getCamera().combined);
		batch.begin();
		batch.draw(Assets.background, -800.0F, 0.0F);
		batch.draw(Assets.building, -210.0F, 0.0F);
		batch.end();

		this.stage.act(delta);
		this.stage.draw();

		Matrix4 cameraCopy = super.getCamera().combined.cpy();
		
		super.getRenderer().render(super.getWorld(), cameraCopy.scl(BoxToWorld));
		super.getWorld().step(1.0F / 60.0F, 6, 2); ///< FPS 60 ���� �׸���.
		
		timeCount += Gdx.graphics.getDeltaTime();
		if(timeCount >= 1.0F)
		{	
			Random random = new Random();
			if(!quakeStart)
			{	
				if(random.nextFloat() >= 0.9)
				{
					quakeStart = true;
				}
			}
			else if(!quakeEnd)
			{
				if(countdown > 0)
				{
					if(countdown < 10 && !building.isCollapsing())
					{
						building.collapse();
					}
					else if(!building.isCollapsing())
					{
						building.throwDown();
					}
					
				}
				else
				{
					quakeEnd = true;
					playerActor.tgm = true;
					building.fix();
					game.setScreen(new CollapsedSchoolScreen(game, stage, super.getWorld(), super.getRenderer(), playerActor, building));
					this.dispose();
				}
				countdown--;
			}
			else
			{
				
			}
			timeCount = 0;
			
			if(playerActor.dead)
			{
				game.setScreen(new GameOverScreen(game));
				/*
				batch.begin();
				batch.draw(Assets.gameover, 0, 0);
				batch.end();*/
			}
		}
		
		if(!quakeStart || quakeEnd)
		{
			super.getCamera().position.x = playerActor.getX() * BoxToWorld;
		}
		else
		{
			if(((int) (timeCount * 10)) % 2 == 1)
				super.getCamera().position.x = playerActor.getX() * BoxToWorld - 2;
			else
				super.getCamera().position.x = playerActor.getX() * BoxToWorld + 2;
			
		}
		super.getCamera().update();
		
		batch.setProjectionMatrix(super.getCamera().combined);
		batch.begin();
		building.draw(batch);
		batch.end();
		
		hud.update(quakeStart, countdown);
		hud.stage.draw();
		
		
	}
	
	/** @brief
	 */
	@Override
	public void resize(int width, int height)
	{
		super.resize(width, height);
	}

	/** @brief
	 */
	@Override
	public void dispose() 
	{
		//batch.dispose();
		//super.dispose();
	}
}

/**
 * @file ScoreScreen.java
 * @brief ScoreScreen
 */


package com.quakesurvival.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator.FreeTypeFontParameter;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.quakesurvival.game.QuakeSurvivalGame;

/**
 * @brief This class is a Class that shows the highScore by getting scores from other classes.
 * @n
 * @author oheong
 *
 */
public class ScoreScreen extends AbstractScreen
{
	private QuakeSurvivalGame game;
	private CollapsedSchoolScreen getscorescreen;   //�� Ŭ�������� ������ �޾ƿ;���.
	
	private Rectangle returnMain;
	private Vector3 touchPoint;
	private Texture returnMainimg;
	private BitmapFont font;
	private Label scoreLabel;
	private Label yourScore;
	public Stage stage;
	int highscore = 0;
	
	String[] highScores = {"180��"};
	
	/** @brief
	 */
	public ScoreScreen (QuakeSurvivalGame game)
	{
		this.game = game;
		returnMain = new Rectangle(0, 0, 60, 60);
		touchPoint = new Vector3();
		returnMainimg = new Texture(Gdx.files.internal("return.jpg"));
		scoreLabel = new Label(String.valueOf(highScores[0]), new Label.LabelStyle(new BitmapFont(), Color.BLACK));
		yourScore = new Label("YOUR SCORE!!", new Label.LabelStyle(new BitmapFont(), Color.BLACK));
		stage = new Stage();
		
		FreeTypeFontGenerator generator = new FreeTypeFontGenerator(Gdx.files.internal("fonts\\koverwatch.ttf"));
		FreeTypeFontParameter parameter = new FreeTypeFontParameter();
		
		parameter.characters = "0123456789��YOUR SCORE!";
		parameter.size = 108;
		font = generator.generateFont(parameter);
		
		Table table = new Table();
		
		scoreLabel = new Label(String.valueOf(highScores[0]), new Label.LabelStyle(font, Color.BLACK));
		yourScore = new Label("YOUR SCORE!!", new Label.LabelStyle(font, Color.BLACK));
		
		table.add(yourScore).expandX().padTop(10);
		table.add(scoreLabel).expandX().padTop(10);
		stage.addActor(table);
	}

	/**
	 * @brief brief description of getScore()
	 * @brief This is a function that scores points on each screen of the game and stores them in the highScore array.
	 * @n
	 * @param score
	 */
	public void getScore (int score)
	{
		//���� �޾ƿ� �Լ�
//		if (highscore < getscorescreen.score)
//			highscore = getscorescreen.score;
		
	}
	
	/** 
	 * @brief This function returns to the mainMenuScreen again when the button of the specified area is clicked, and displays the labels to display the scores to show on the current screen.
	 * 
	 */
	public void update () 
	{
		if (Gdx.input.justTouched())
		{
			super.camera.unproject(touchPoint.set(Gdx.input.getX(), Gdx.input.getY(), 0));
			if (returnMain.contains(touchPoint.x, touchPoint.y))
			{
				game.setMainMenuScreen();
				return;
			}
		}
		yourScore.setText("YOUR\nSCORE!");
		yourScore.setPosition(80, 280);
		scoreLabel.setText(String.valueOf(highScores[0]));
		scoreLabel.setPosition(300, 150);
		
	}

	/** @brief
	 */
	@Override
	public void dispose()
	{
		stage.dispose();
	}
	
	/** @brief
	 */
	@Override
	public void render(float delta)
	{
		Gdx.gl.glClearColor(0.6f, 0.5f, 0.2f, 0);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		game.batch.begin();
		
		stage.draw();
		game.batch.draw(returnMainimg, 0, 0, 60, 60);//�ȳ��ȤФп�?
		//stage.draw();
		game.batch.end();
		update();
	}
}

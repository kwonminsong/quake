

package com.quakesurvival.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator.FreeTypeFontParameter;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.quakesurvival.game.QuakeSurvivalGame;
import com.quakesurvival.game.attribute.Assets;


/**
 * @brief This class sets the game difficulty level and background. In this class, clicking on the difficulty and background selection part, the integer value 'setlevel', 'setbackground' variable receives the value, the game background and difficulty level are set.
 * @n
 * @author oheong
 */
public class SettingScreen extends AbstractScreen
{
	private Stage stage;
	private QuakeSurvivalGame game;
	private ImageButton returnButton, easyButton, hardButton;
	private BitmapFont font;
	private Label levelLabel1, levelLabel2;
	
	//����, ��� �������� ���õ� �������� �޾Ƽ� ���ӿ� ����
	int setlevel, setbackground;
	
	/** @brief
	 */
	public SettingScreen(final QuakeSurvivalGame game)
	{
		this.game = game;
		stage = new Stage();
		
		FreeTypeFontGenerator generator = new FreeTypeFontGenerator(Gdx.files.internal("fonts\\koverwatch.ttf"));
	    FreeTypeFontParameter parameter = new FreeTypeFontParameter();
	        
	    parameter.characters = ".���̵�ó�������Ͻôºп�����õ�մϴٻ����Ҽ�����";
	    parameter.size = 50;
	    font = generator.generateFont(parameter);
	    
	    levelLabel1 = new Label("���̵�", new Label.LabelStyle(font, Color.ORANGE));
	    levelLabel2 = new Label("", new Label.LabelStyle(font, Color.ORANGE));
	    levelLabel1.setPosition(400, 550, Align.center);
	    levelLabel2.setPosition(400, 200, Align.center);
	    
		TextureRegionDrawable return0 = new TextureRegionDrawable(Assets.return0);
		TextureRegionDrawable return1 = new TextureRegionDrawable(Assets.return1);
		TextureRegionDrawable easy0 = new TextureRegionDrawable(Assets.easy0);
		TextureRegionDrawable easy1 = new TextureRegionDrawable(Assets.easy1);
		TextureRegionDrawable hard0 = new TextureRegionDrawable(Assets.hard0);
		TextureRegionDrawable hard1 = new TextureRegionDrawable(Assets.hard1);
	
		returnButton = new ImageButton(return0, return0, return1);
		easyButton = new ImageButton(easy0, easy0, easy1);
		hardButton = new ImageButton(hard0, hard0, hard1);
		
		returnButton.setPosition(480, 20);
		easyButton.setPosition(100, 300);
		hardButton.setPosition(450, 300);
		
		
		returnButton.addListener(new ClickListener() 
		{
			@Override
			public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor)
			{
				returnButton.setChecked(true);
			}
			
			@Override
			public void exit(InputEvent event, float x, float y, int pointer, Actor fromActor)
			{
				returnButton.setChecked(false);
			}
			
			@Override
			public void clicked(InputEvent event, float x, float y)
			{
				game.setMainMenuScreen();
			}	
		});
		
		easyButton.addListener(new ClickListener() 
		{
			@Override
			public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor)
			{
				levelLabel2.setText("ó�� �����Ͻô� �п��� ��õ�մϴ�.");
				levelLabel2.setAlignment(Align.center);
			}
			
			@Override
			public void exit(InputEvent event, float x, float y, int pointer, Actor fromActor)
			{
				levelLabel2.setText("");
			}
			
			@Override
			public void clicked(InputEvent event, float x, float y)
			{		
				hardButton.setChecked(false);
				easyButton.setChecked(true);
				Assets.ishard = false;
			}	
		});
		
		hardButton.addListener(new ClickListener() 
		{	
			@Override
			public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor)
			{
				levelLabel2.setText("������ �� �����ϴ�.");
				levelLabel2.setAlignment(Align.center);
				
			}
			
			@Override
			public void exit(InputEvent event, float x, float y, int pointer, Actor fromActor)
			{
				levelLabel2.setText("");
			}
			
			@Override
			public void clicked(InputEvent event, float x, float y)
			{
				easyButton.setChecked(false);
				hardButton.setChecked(true);
				Assets.ishard = true;
			}	
		});
		
		

	    stage.addActor(levelLabel1);
		stage.addActor(levelLabel2);
		stage.addActor(returnButton);
		stage.addActor(easyButton);
		stage.addActor(hardButton);
		
		Gdx.input.setInputProcessor(stage);
	}
	
	@Override
	public void show()
	{
		Gdx.input.setInputProcessor(stage);
	
	}



	
	/** @brief
	 */
	@Override
	public void render(float delta)
	{
		Gdx.gl.glClearColor(0, 0, 0, 1.0F);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		stage.act();
		stage.draw();
	}
}

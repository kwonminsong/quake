/**
 * @file ShareScreen.java
 * @brief ShareScreen
 */

package com.quakesurvival.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator.FreeTypeFontParameter;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Action;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.ui.CheckBox;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.quakesurvival.game.QuakeSurvivalGame;
import com.quakesurvival.game.attribute.Assets;
import com.quakesurvival.game.attribute.Supplies;
import com.quakesurvival.game.attribute.Survivor;
import com.quakesurvival.game.controls.ClickHandler;


public class ShareScreen extends AbstractScreen
{
	private QuakeSurvivalGame game;
	private Stage stage;
	private ImageButton[] breadButtons, waterButtons;
	private Table table;
	private Image faceImage1, faceImage2, faceImage3;
	private BitmapFont font;
	private Label shareLabel, resultLabel, breadLabel, waterLabel;
	private Rectangle shareButton, returnButton;
	private CollapsedSchoolScreen collapsedSchoolScreen;
	private Survivor[] survivors;
	private Supplies supplies;
	
	private Vector3 touchPoint;
	
	int day = 0;
	/** @brief
	 */
	public ShareScreen(QuakeSurvivalGame game, CollapsedSchoolScreen collapsedSchoolScreen, Skin skin, Survivor[] survivors, Supplies supplies)
	{
		this.game = game;
		this.collapsedSchoolScreen = collapsedSchoolScreen;
		this.survivors = survivors;
		this.supplies = supplies;
		
		stage = new Stage();
		touchPoint = new Vector3();
	    shareButton = new Rectangle(600, 0, 200, 100);
	    returnButton = new Rectangle(0, 0, 100, 100);

		FreeTypeFontGenerator generator = new FreeTypeFontGenerator(Gdx.files.internal("fonts\\koverwatch.ttf"));
	    FreeTypeFontParameter parameter = new FreeTypeFontParameter();
	    
	    parameter.characters = "0123456789.!�����ķ�����������ҽð��Դϴ��̺����մϴ�";
	    parameter.size = 30;
	    font = generator.generateFont(parameter);
	    
	    breadLabel = new Label(": " + supplies.getBread(), new Label.LabelStyle(font, Color.BLACK));
	    waterLabel = new Label(": " + supplies.getWater(), new Label.LabelStyle(font, Color.BLACK));
	    shareLabel = new Label("���� �ķ��� ������� �� �ð��Դϴ� ...", new Label.LabelStyle(font, Color.BLACK));
	    resultLabel = new Label("", new Label.LabelStyle(font, Color.RED));
		
	    
	    breadLabel.setPosition(50, 550);
	    waterLabel.setPosition(50, 500);
	    shareLabel.setPosition(400, 450, Align.center);
		resultLabel.setPosition(400, 400, Align.center);
		
		stage.addActor(breadLabel);
		stage.addActor(waterLabel);
		stage.addActor(shareLabel);
		stage.addActor(resultLabel);
		
		
		TextureRegionDrawable bread0 = new TextureRegionDrawable(Assets.bread0);
		TextureRegionDrawable bread1 = new TextureRegionDrawable(Assets.bread1);
		TextureRegionDrawable water0 = new TextureRegionDrawable(Assets.water0);
		TextureRegionDrawable water1 = new TextureRegionDrawable(Assets.water1);
		
		Image breadImg = new Image(Assets.bread1);
		Image waterImg = new Image(Assets.water1);
		
		breadImg.setPosition(0, 550);
		waterImg.setPosition(0, 500);
		stage.addActor(breadImg);
		stage.addActor(waterImg);
				
		breadButtons = new ImageButton[3];
		for(int i = 0; i < breadButtons.length; i++)
		{
			breadButtons[i] = new ImageButton(bread0, bread0, bread1);
		}
		
		waterButtons = new ImageButton[3];
		for(int i = 0; i < waterButtons.length; i++)
		{
			waterButtons[i] = new ImageButton(water0, water0, water1);
		}
		
		faceImage1 = new Image(survivors[0].showFace());
		faceImage2 = new Image(survivors[1].showFace());
		faceImage3 = new Image(survivors[2].showFace());
		
		table = new Table();
		table.setBounds(100, 100, 600, 300);
		table.add(faceImage1).expandX();
		table.add(faceImage2).expandX();
		table.add(faceImage3).expandX();
		table.row().expandX().spaceBottom(20);
		table.add(breadButtons[0]).expandX();
		table.add(breadButtons[1]).expandX();
		table.add(breadButtons[2]).expandX();
		table.row().expandX().spaceBottom(20);
		table.add(waterButtons[0]).expandX();
		table.add(waterButtons[1]).expandX();
		table.add(waterButtons[2]).expandX();
		stage.addActor(table);
	}
	
	@Override
	public void show()
	{
		Gdx.input.setInputProcessor(stage);
		
		for(int i = 0; i < breadButtons.length; i++)
		{
			waterButtons[i].setChecked(false);
			breadButtons[i].setChecked(false);
		}
		
		faceImage1.setDrawable(new TextureRegionDrawable(survivors[0].showFace()));
		faceImage2.setDrawable(new TextureRegionDrawable(survivors[1].showFace()));
		faceImage3.setDrawable(new TextureRegionDrawable(survivors[2].showFace()));
	    breadLabel.setText(": " + supplies.getBread());
	    waterLabel.setText(": " + supplies.getWater());
	    
	}
	
	private boolean feed()
	{
		int bread = 0, water = 0;
		
		for(int i = 0; i < breadButtons.length; i++)
		{
			if(breadButtons[i].isChecked())
			{
				bread++;
			}
			
			if(waterButtons[i].isChecked())
			{
				water++;
			}
		}
		
		if(supplies.consume(bread, water))
		{
			for(int i = 0; i < breadButtons.length; i++)
			{
				if(breadButtons[i].isChecked())
				{
					survivors[i].eat();
				}
				
				if(waterButtons[i].isChecked())
				{
					survivors[i].drink();
				}
			}
			
			return true;
		}
		else
		{
			return false;
		}
			
		
	}
	
	/** @brief
	 */
	@Override
	public void render (float delta) 
	{
		Gdx.gl.glClearColor(0.8F, 0.9F, 1.0F, 1.0F);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		if(Gdx.input.justTouched())
		{
			super.camera.unproject(touchPoint.set(Gdx.input.getX(), Gdx.input.getY(), 0));
			
			if (shareButton.contains(touchPoint.x, touchPoint.y)) 
			{
				boolean feedback = feed();
				if(feedback)
				{
					resultLabel.setText("");
					resultLabel.setAlignment(Align.center);
					collapsedSchoolScreen.daily = true;
					game.setScreen(new DayScreen(game, collapsedSchoolScreen, ++day));

					return;
				}
				else
				{
					resultLabel.getColor().a = 1;
					resultLabel.setText("�ķ��� �����մϴ� !");
					resultLabel.setAlignment(Align.center);
					resultLabel.addAction(Actions.fadeOut(0.75F));
				}
			}
			
			if (returnButton.contains(touchPoint.x, touchPoint.y))
			{
				game.setScreen(collapsedSchoolScreen);
			}
		}
		
		stage.draw();
		stage.act();
	}
	
}

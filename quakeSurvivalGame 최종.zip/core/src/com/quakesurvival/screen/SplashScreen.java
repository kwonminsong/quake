/**
 * @file SplashScreen.java
 * @brief SplashScreen 
 */

package com.quakesurvival.screen;

import java.util.Random;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator.FreeTypeFontParameter;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.quakesurvival.game.QuakeSurvivalGame;

public class SplashScreen extends AbstractScreen
{
	/*
	Label tipLabel;
	Stage stage;
	
	QuakeSurvivalGame game;
	BitmapFont font;
	int currentMessage = 0;
	Random random = new Random();
	

	public SplashScreen(QuakeSurvivalGame game) 
	{
		this.game = game;	
		stage = new Stage();

		Image splashImage = new Image(""); 
		
	


		stage.addActor(table);

	}
	

	public void update()
	{
		currentMessage = random.nextInt(8);
		
		tipLabel.setPosition(300, 150);
	}

	@Override
	public void show()
	{
		
	}

	@Override
	public void render(float delta)
	{
		Gdx.gl.glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		super.camera.update();
		
		game.batch.begin();
		stage.draw();
		game.batch.end();
	}
	

	@Override
	public void dispose(){
		stage.dispose();
	}
	
	
*/
	
}
/**
 * @file TextureUtils.java
 * @brief TextureUtils 
 */

package com.quakesurvival.utils;

import com.badlogic.gdx.tools.texturepacker.TexturePacker;

public class TextureUtils 
{
	/** @brief
	 */
	public static void main(String[] args)
	{
		TexturePacker.process("..\\images", "..\\core\\assets\\textures", "textures");
	}
}

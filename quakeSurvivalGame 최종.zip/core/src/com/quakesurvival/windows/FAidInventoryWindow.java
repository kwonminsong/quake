package com.quakesurvival.windows;

import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.Window;
import com.badlogic.gdx.scenes.scene2d.utils.DragAndDrop;
import com.quakesurvival.actors.SlotActor;
import com.quakesurvival.game.attribute.FAidInventory;
import com.quakesurvival.game.controls.FAidClickHandler;
import com.quakesurvival.game.controls.Slot;
import com.quakesurvival.game.controls.SlotSource;
import com.quakesurvival.game.controls.SlotTarget;

public class FAidInventoryWindow extends Window {

	public FAidInventoryWindow(Stage stage, FAidInventory faidInventory, DragAndDrop dragAndDrop, Skin skin) {
		super("FAidInventory", skin);
	
		setPosition(400, 100);
		defaults().space(8);
		row().fill().expandX();
		
		int i = 0;
		for (Slot slot : faidInventory.getSlots()) {
			SlotActor slotActor = new SlotActor(stage, skin, slot);
			dragAndDrop.addSource(new SlotSource(slotActor));
			dragAndDrop.addTarget(new SlotTarget(slotActor));
			add(slotActor).size(100,100);

			i++;
			
		}
		row();
		Label label1 = new Label("", skin);
		add(label1);
		Label label2 = new Label("", skin);
		add(label2);
		TextButton FAidButton = new TextButton("      CURE      ", skin);
		FAidButton.addListener(new FAidClickHandler(this));
		add(FAidButton);
		
		pack();

		setVisible(false);
	}

}
